setwd("D:/zouyuping2023/task/GBD/Disease/RHD-2/APC预测/") #设置工作路径
library(BAPC)
library(INLA)
library(nordpred)
library(reshape)
library(data.table)
library(tidyr)
library(tidyverse)
library(epitools)
library(ggplot2)
#使用BAPC包时，注意以下几点
#人口数据和疾病数据需是整数；发病率表和人口统计表的横向是年份，纵向是年龄；
#发病率表中17年以后的年份也要有，数据是NA
###读取疾病数据
RA <- fread("RHD-5-Ages.csv")
###发病率的年龄分层(疾病的年龄根据自己的研究需要进行选择)
ages <- c("Under 5","5 to 9","10 to 14","15 to 19","20 to 24","25 to 29","30 to 34","35 to 39",
          "40 to 44","45 to 49","50 to 54","55 to 59","60 to 64","65 to 69","70 to 74","75 to 79",
          "80 to 84","85 to 89","90 to 94","95 plus")


RA$age_name[RA$age_name=="<5 years"] <- "Under 5"
RA$age_name[RA$age_name=="5-9 years"] <- "5 to 9"
RA$age_name[RA$age_name=="10-14 years"] <- "10 to 14"
RA$age_name[RA$age_name=="15-19 years"] <- "15 to 19"
RA$age_name[RA$age_name=="20-24 years"] <- "20 to 24"
RA$age_name[RA$age_name=="25-29 years"] <- "25 to 29"
RA$age_name[RA$age_name=="30-34 years"] <- "30 to 34"
RA$age_name[RA$age_name=="35-39 years"] <- "35 to 39"
RA$age_name[RA$age_name=="40-44 years"] <- "40 to 44"
RA$age_name[RA$age_name=="45-49 years"] <- "45 to 49"
RA$age_name[RA$age_name=="50-54 years"] <- "50 to 54"
RA$age_name[RA$age_name=="55-59 years"] <- "55 to 59"
RA$age_name[RA$age_name=="60-64 years"] <- "60 to 64"
RA$age_name[RA$age_name=="65-69 years"] <- "65 to 69"
RA$age_name[RA$age_name=="70-74 years"] <- "70 to 74"
RA$age_name[RA$age_name=="75-79 years"] <- "75 to 79"
RA$age_name[RA$age_name=="80-84"] <- "80 to 84"
RA$age_name[RA$age_name=="85-89"] <- "85 to 89"
RA$age_name[RA$age_name=="90-94"] <- "90 to 94"
RA$age_name[RA$age_name=="95+ years"] <- "95 plus"

### for incidence for male
RA_ages_male <- RA[age_name %in% ages & 
                      sex_name == 'Male' &
                      metric_name == 'Number' &
                      location_name == 'Global'&
                      measure_name == 'Incidence',
                   .(age_id, age_name, year, val)]
RA_ages_male <- RA_ages_male[order(age_id),]
#for incidence for female
RA_ages_female <- RA[age_name %in% ages & 
                       sex_name == 'Female' &
                       metric_name == 'Number' &
                       location_name == 'Global'&
                       measure_name == 'Incidence',
                     .(age_id, age_name, year, val)]
RA_ages_female <- RA_ages_female[order(age_id),]


RA_ages_male_n <- dcast(data = RA_ages_male, age_id + age_name ~ year)
RA_ages_male_n <- RA_ages_male_n[order(RA_ages_male_n$age_id),]

RA_ages_female_n <- dcast(data = RA_ages_female, age_id + age_name ~ year)
RA_ages_female_n <- RA_ages_female_n[order(RA_ages_female_n$age_id),]

#将数据格式变为BAPC可以识别的形式
RA_ages_male <- t(RA_ages_male_n) %>% as.data.frame()
RA_ages_male <- RA_ages_male[-c(1,2),]
RA_ages_male <- apply(RA_ages_male,c(1,2),as.integer) %>% as.data.frame()
names(RA_ages_male) <- RA_ages_male_n$age_name

RA_ages_female <- t(RA_ages_female_n) %>% as.data.frame()
RA_ages_female <- RA_ages_female[-c(1,2),]
RA_ages_female <- apply(RA_ages_female,c(1,2),as.integer) %>% as.data.frame()
names(RA_ages_female) <- RA_ages_female_n$age_name
#补充没有疾病数据的年份，这里是预测22-50年内的趋势，预测的年份根据自己的需要选择
#男性
RA_ages_male_pro <- matrix(data = NA,nrow = 29,ncol = 20) %>% as.data.frame()
row.names(RA_ages_male_pro) <- seq(2022,2050,1)
colnames(RA_ages_male_pro) <- RA_ages_male_n$age_name
RA_ages_male <- rbind(RA_ages_male,RA_ages_male_pro)
#女性
RA_ages_female_pro <- matrix(data = NA,nrow = 29,ncol = 20) %>% as.data.frame()
row.names(RA_ages_female_pro) <- seq(2022,2050,1)
colnames(RA_ages_female_pro) <- RA_ages_female_n$age_name
RA_ages_female <- rbind(RA_ages_female,RA_ages_female_pro)

###获取1990-2021的各年龄段人口规模数据，GBD数据库菜单栏Estimate选择Population，根据自己的需要下载
var_name <- c("location_name","sex_name","year","age_id","age_name","val")###设置需要的变量
GBD_population <- fread('90-21年人口年龄分层.csv')
GBD_population <- GBD_population %>% select(all_of(var_name)) %>% 
  filter(age_name %in% ages)


###2018-2100各年龄段人群规模预测数据整理
#需要提取的变量
prediction_var_name <- c("location_name","sex","age_group_id","age_group_name","year_id","val")
GBD_population_prediction <- fread("Population-Prediction_2018-2100.csv") %>% 
  select(all_of(prediction_var_name)) %>% filter(age_group_name %in% ages & year_id %in% 2022:2050)
#重新修改列名，使其与GBD_population列名一致，便于合并
names(GBD_population_prediction) <- c("location_name","sex_name","age_id","age_name","year","val")
# 合并数据
GBD <- rbind(GBD_population,GBD_population_prediction)

# 将数据整理成需要的格式
# 这里对全球情况进行预测，性别区分
GBD_Global_Male <- subset(GBD,location_name=="Global"&sex_name=="Male")
GBD_Global_Male_n <- dcast(data = GBD_Global_Male,year~age_id,value.var = c("val"))
GBD_Global_Male_n <- as.data.frame(GBD_Global_Male_n)
rownames(GBD_Global_Male_n)=GBD_Global_Male_n[,1]
GBD_Global_Male_n <- GBD_Global_Male_n[,-1]
names(GBD_Global_Male_n) <- RA_ages_male_n$age_name

GBD_Global_Female <- subset(GBD,location_name=="Global"&sex_name=="Female")
GBD_Global_Female_n <- dcast(data = GBD_Global_Female,year~age_id,value.var = c("val"))
GBD_Global_Female_n <- as.data.frame(GBD_Global_Female_n)
rownames(GBD_Global_Female_n)=GBD_Global_Female_n[,1]
GBD_Global_Female_n <- GBD_Global_Female_n[,-1]
names(GBD_Global_Female_n) <- RA_ages_female_n$age_name

##读取年龄标准化结构数据
age_stand <- read.csv("2021GBD标准人口.csv")
wstand <- c(age_stand$Percent.of.Population[1:6] %>% as.numeric() %>% sum(),
            age_stand$Percent.of.Population[7:25] %>% as.numeric())/100
#sum of wstand must be 1
sum(wstand)

# 预测
RA_Prediction_male <- APCList(RA_ages_male, GBD_Global_Male_n, gf = 5)
bapc_result_male <- BAPC(RA_Prediction_male, predict = list(npredict = 29, retro = T),
                    secondDiff = FALSE, stdweight = wstand, verbose = TRUE)
# 作图
par(mar = c(5, 4, 4, 2), mfrow = c(1, 1))
plotBAPC(bapc_result_male, scale=10^5, type = 'ageStdRate', showdata = T)
bapc_result_male@agestd.rate
plotBAPC(bapc_result_male, scale = 10^5, type="ageSpecRate",
         probs = c(0.025, seq(0.05, 0.95, by=0.05), 0.975), start=NULL,
         showdata = TRUE, mfrow = NULL, col.fan =sequential_hcl,
         obs.pch=1, obs.col="red", obs.bg="black", obs.lwd=2, obs.cex=1, ln=NULL,mai=c(0.3,0.3,0.3,0.3))

###女性
RA_Prediction_female <- APCList(RA_ages_female, GBD_Global_Female_n, gf = 5)
bapc_result_female <- BAPC(RA_Prediction_female, predict = list(npredict = 29, retro = T),
                    secondDiff = FALSE, stdweight = wstand, verbose = TRUE)
par(mar = c(5, 4, 4, 2), mfrow = c(1, 1))
# 作图
plotBAPC(bapc_result_female, scale=10^5, type = 'ageStdRate', showdata = T)
bapc_result_female@agestd.rate
plotBAPC(bapc_result_female, scale = 10^5, type="ageSpecRate",
         probs = c(0.025, seq(0.05, 0.95, by=0.05), 0.975), start=NULL,
         showdata = TRUE, mfrow = NULL, col.fan =sequential_hcl,
         obs.pch=1, obs.col="red", obs.bg="black", obs.lwd=2, obs.cex=1, ln=NULL,mai=c(0.3,0.3,0.3,0.3))




