##for joinpoint
library(dplyr)
library(ggplot2)
setwd("D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/27个地区/")
RA <- read.csv("RHD-27.csv",header = T)
AAPC <- subset(RA,RA$age=="Age-standardized"&
                 RA$measure=="DALYs (Disability-Adjusted Life Years)"&
                 RA$metric=="Rate"&
                 RA$sex=="Both")
#joinpoint需要发病率以及标准误数据，因此我们需要得到标准误数据
AAPC$SE <-(AAPC$upper-AAPC$lower)/(1.96*2) 
AAPC <- AAPC[,c(2,7,8,11)]
#joinpoint软件要求年份按照升序排列，且一个组放在一起
AAPC <- AAPC[order(AAPC$location,AAPC$year),]
write.csv(AAPC,"DALYs_AAPC.csv")


#数据导出后，继续使用R处理
AAPC <- read.table("D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/22个地区/Incidence-RHD-AAPC.txt",header = T)
AAPC <- AAPC[,c(1,6,7,8)]
names(AAPC)[2:4] <- c("val","lower","upper")
#运行下述代码，把AAPC与95%CI连接起来
AAPC$AAPC <- paste(AAPC$lower,AAPC$upper,sep = "-")
AAPC$AAPC <- paste(AAPC$AAPC,")",sep = "")
AAPC$AAPC <- paste("(",AAPC$AAPC,sep = "")
AAPC$AAPC <- paste(AAPC$val,AAPC$AAPC,sep = " ")
##将1990与2019年的RA发病数以及标准发病率整理好
#1990发病人数
RA_1990 <- subset(RA,RA$year==1990&
                    RA$age=="All ages"&
                    RA$metric=="Number"&
                    RA$measure=="Incidence"&
                    RA$sex=="Both")
RA_1990 <- RA_1990[,c(2,8,9,10)]
RA_1990$val <- round(RA_1990$val,1)
RA_1990$lower <- round(RA_1990$lower,1)
RA_1990$upper <- round(RA_1990$upper,1)
RA_1990$Num_1990 <- paste(RA_1990$lower,RA_1990$upper,sep = "-")
RA_1990$Num_1990 <- paste(RA_1990$Num_1990,")",sep = "")
RA_1990$Num_1990 <- paste("(",RA_1990$Num_1990,sep = "")
RA_1990$Num_1990 <- paste(RA_1990$val,RA_1990$Num_1990,sep = " ")

#2019发病人数
RA_2019 <- subset(RA,RA$year==2021&
                    RA$age=="All ages"&
                    RA$metric=="Number"&
                    RA$measure=="Incidence"&
                    RA$sex=="Both")
RA_2019 <- RA_2019[,c(2,8,9,10)]
RA_2019$val <- round(RA_2019$val,1)
RA_2019$lower <- round(RA_2019$lower,1)
RA_2019$upper <- round(RA_2019$upper,1)
RA_2019$Num_2019 <- paste(RA_2019$lower,RA_2019$upper,sep = "-")
RA_2019$Num_2019 <- paste(RA_2019$Num_2019,")",sep = "")
RA_2019$Num_2019 <- paste("(",RA_2019$Num_2019,sep = "")
RA_2019$Num_2019 <- paste(RA_2019$val,RA_2019$Num_2019,sep = " ")

#1990ASR
ASR_1990 <- subset(RA,RA$year==1990&
                     RA$age=="Age-standardized"&
                     RA$metric=="Rate"&
                     RA$measure=="Incidence"&
                     RA$sex=="Both")
ASR_1990 <- ASR_1990[,c(2,8,9,10)]
ASR_1990$val <- round(ASR_1990$val,1)
ASR_1990$lower <- round(ASR_1990$lower,1)
ASR_1990$upper <- round(ASR_1990$upper,1)
ASR_1990$ASR_1990 <- paste(ASR_1990$lower,ASR_1990$upper,sep = "-")
ASR_1990$ASR_1990 <- paste(ASR_1990$ASR_1990,")",sep = "")
ASR_1990$ASR_1990 <- paste("(",ASR_1990$ASR_1990,sep = "")
ASR_1990$ASR_1990 <- paste(ASR_1990$val,ASR_1990$ASR_1990,sep = " ")

#2019ASR
ASR_2019 <- subset(RA,RA$year==2021&
                     RA$age=="Age-standardized"&
                     RA$metric=="Rate"&
                     RA$measure=="Incidence"&
                     RA$sex=="Both")
ASR_2019 <- ASR_2019[,c(2,8,9,10)]
ASR_2019$val <- round(ASR_2019$val,1)
ASR_2019$lower <- round(ASR_2019$lower,1)
ASR_2019$upper <- round(ASR_2019$upper,1)
ASR_2019$ASR_2019 <- paste(ASR_2019$lower,ASR_2019$upper,sep = "-")
ASR_2019$ASR_2019 <- paste(ASR_2019$ASR_2019,")",sep = "")
ASR_2019$ASR_2019 <- paste("(",ASR_2019$ASR_2019,sep = "")
ASR_2019$ASR_2019 <- paste(ASR_2019$val,ASR_2019$ASR_2019,sep = " ")

#数据整合
RA_1990 <- RA_1990[,c(1,5)]
ASR_1990 <- ASR_1990[,c(1,5)]
RA_2019 <- RA_2019[,c(1,5)]
ASR_2019 <- ASR_2019[,c(1,5)]
AAPC <- AAPC[,c(1,5)]

Incidence <- merge(RA_1990,ASR_1990,by = "location")
Incidence <- merge(Incidence,RA_2019,by = "location")
Incidence <- merge(Incidence,ASR_2019,by = "location")
Incidence <- merge(Incidence,AAPC,by = "location")
write.csv(Incidence,"Result for AAPC Incidence.csv")











