###有些文献中描绘疾病负担的年度变化情况使用的是EAPC（平均年度百分比变化）
###这里简单介绍一下计算过程，以及文章中信息表格的制作
###更推荐使用AAPC
library(dplyr)
library(ggplot2)
T1D <- read.csv("D:/zouyuping2023/task/GBD/Disease/RHD-2/以表格形式展示数据/RHD-204.csv")
T1D_1990_2019 <- read.csv("D:/zouyuping2023/task/GBD/Disease/RHD-2/以表格形式展示数据/RHD-204-Change.csv",header = T)
T1D$location_name[T1D$location_name == "Türkiye"] = "Turkey"
unique(T1D_1990_2019$location_name)
unique(T1D$location_name)
setdiff(unique(T1D_1990_2019$location_name),unique(T1D$location_name))
setdiff(unique(T1D$location_name),unique(T1D_1990_2019$location_name))
intersect(unique(T1D$location_name),unique(T1D_1990_2019$location_name))
#T1D<-T1D[,-1]
#T1D <- subset(T1D,T1D$sex_name=="Both" )
#1990发病人数
T1D_1990 <- subset(T1D,T1D$year==1990 &
                     T1D$age_name=="All ages" &
                     T1D$metric_name=="Number" &
                     T1D$sex_name=="Both"&
                     T1D$measure_name=="DALYs (Disability-Adjusted Life Years)")
T1D_1990 <- T1D_1990[,c(4,14,15,16)]
T1D_1990$val <- round(T1D_1990$val,0)
T1D_1990$upper <- round(T1D_1990$upper,0)
T1D_1990$lower <- round(T1D_1990$lower,0)
T1D_1990$Num_1990 <- paste(T1D_1990$lower,T1D_1990$upper,sep = "to")
T1D_1990$Num_1990 <- paste(T1D_1990$Num_1990,")",sep = "")
T1D_1990$Num_1990 <- paste("(",T1D_1990$Num_1990,sep = "")
T1D_1990$Num_1990 <- paste(T1D_1990$val,T1D_1990$Num_1990,sep = " ")

# 2019发病人数
T1D_2019 <- subset(T1D,T1D$year==2021 &
                     T1D$age_name=="All ages" &
                     T1D$metric_name=="Number" &
                     T1D$sex_name=="Both"&
                     T1D$measure_name=="DALYs (Disability-Adjusted Life Years)")
T1D_2019 <- T1D_2019[,c(4,14,15,16)]
T1D_2019$val <- round(T1D_2019$val,0)
T1D_2019$upper <- round(T1D_2019$upper,0)
T1D_2019$lower <- round(T1D_2019$lower,0)
T1D_2019$Num_2019 <- paste(T1D_2019$lower,T1D_2019$upper,sep = "to")
T1D_2019$Num_2019 <- paste(T1D_2019$Num_2019,")",sep = "")
T1D_2019$Num_2019 <- paste("(",T1D_2019$Num_2019,sep = "")
T1D_2019$Num_2019 <- paste(T1D_2019$val,T1D_2019$Num_2019,sep = " ")

#1990 ASR
T1D_1990_ASR <- subset(T1D,T1D$year==1990 &
                         T1D$age_name=="Age-standardized" &
                         T1D$metric_name=="Rate" &
                         T1D$sex_name=="Both"&
                         T1D$measure_name=="DALYs (Disability-Adjusted Life Years)")
T1D_1990_ASR <- T1D_1990_ASR[,c(4,14,15,16)]
T1D_1990_ASR$val <- round(T1D_1990_ASR$val,2)
T1D_1990_ASR$upper <- round(T1D_1990_ASR$upper,2)
T1D_1990_ASR$lower <- round(T1D_1990_ASR$lower,2)
T1D_1990_ASR$Num_1990 <- paste(T1D_1990_ASR$lower,T1D_1990_ASR$upper,sep = "to")
T1D_1990_ASR$Num_1990 <- paste(T1D_1990_ASR$Num_1990,")",sep = "")
T1D_1990_ASR$Num_1990 <- paste("(",T1D_1990_ASR$Num_1990,sep = "")
T1D_1990_ASR$Num_1990 <- paste(T1D_1990_ASR$val,T1D_1990_ASR$Num_1990,sep = " ")

#2019 ASR
T1D_2019_ASR <- subset(T1D,T1D$year==2021 &
                         T1D$age_name=="Age-standardized" &
                         T1D$metric_name=="Rate" &
                         T1D$sex_name=="Both"&
                         T1D$measure_name=="DALYs (Disability-Adjusted Life Years)")
T1D_2019_ASR <- T1D_2019_ASR[,c(4,14,15,16)]
T1D_2019_ASR$val <- round(T1D_2019_ASR$val,2)
T1D_2019_ASR$upper <- round(T1D_2019_ASR$upper,2)
T1D_2019_ASR$lower <- round(T1D_2019_ASR$lower,2)
T1D_2019_ASR$Num_2019 <- paste(T1D_2019_ASR$lower,T1D_2019_ASR$upper,sep = "to")
T1D_2019_ASR$Num_2019 <- paste(T1D_2019_ASR$Num_2019,")",sep = "")
T1D_2019_ASR$Num_2019 <- paste("(",T1D_2019_ASR$Num_2019,sep = "")
T1D_2019_ASR$Num_2019 <- paste(T1D_2019_ASR$val,T1D_2019_ASR$Num_2019,sep = " ")
#change
T1D_change <- subset(T1D_1990_2019, T1D_1990_2019$measure_name=="DALYs (Disability-Adjusted Life Years)"&
                       T1D_1990_2019$metric_name=="Number"&
                       T1D_1990_2019$sex_name=="Both"&
                       T1D_1990_2019$age_name=="All ages")
T1D_change <- T1D_change[,c(4,15,16,17)]
T1D_change$val <- round(T1D_change$val,4)*100
T1D_change$upper <- round(T1D_change$upper,4)*100
T1D_change$lower <- round(T1D_change$lower,4)*100
T1D_change$Num_change <- paste(T1D_change$lower,T1D_change$upper,sep = "to")
T1D_change$Num_change <- paste(T1D_change$Num_change,")",sep = "")
T1D_change$Num_change <- paste("(",T1D_change$Num_change,sep = "")
T1D_change$Num_change <- paste(T1D_change$val,T1D_change$Num_change,sep = " ")



AAPC<-read.table("D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/204个国家/DALYs-RHD-AAPC.txt",sep="",header=T)
AAPC$location[AAPC$location == "Türkiye"] = "Turkey"
AAPC<-AAPC[,c(1,6,7,8,11)]
names(AAPC)[2:4]<-c("val","lower","uper")
AAPC$AAPC<-paste(AAPC$lower,AAPC$uper,sep = "to")
AAPC$AAPC<-paste(AAPC$AAPC,")",sep = "")
AAPC$AAPC<-paste("(",AAPC$AAPC,sep = "")
AAPC$AAPC<-paste(AAPC$val,AAPC$AAPC,sep = " ")

### 数据整合
T1D_1990 <- T1D_1990[,c(1,5)]  ###取地区和整合好的变量
T1D_1990_ASR <- T1D_1990_ASR[,c(1,5)]
T1D_2019 <- T1D_2019[,c(1,5)]
T1D_2019_ASR <- T1D_2019_ASR[,c(1,5)]
AAPC <- AAPC[,c(1,5,6)]
AAPC[AAPC=="Central Europe Eastern Europe and Central Asia"]="Central Europe, Eastern Europe, and Central Asia"
AAPC[AAPC=="Southeast Asia East Asia and Oceania"]="Southeast Asia, East Asia, and Oceania"
AAPC$P.Value[AAPC$P.Value<0.001]="<0.001"
AAPC[,4]<-AAPC[,2]
AAPC<-AAPC[,-2]
colnames(AAPC)<-c('location_name','AAPC','V4')
T1D_change <- T1D_change[,c(1,5)]
Incidence <- merge(T1D_1990,T1D_1990_ASR,by='location_name')
Incidence <- merge(Incidence,T1D_2019,by='location_name')
Incidence <- merge(Incidence,T1D_2019_ASR,by='location_name')
Incidence <- merge(Incidence,T1D_change,by='location_name')
Incidence <- merge(Incidence,AAPC,by='location_name')



names(Incidence)[1:8]<-c("location","Num_1990","ASR_1990","Num_2021","ASR_2021","Change in counts from 1990 to 2021","AAPC in ASR from 1990 to 2021","AAPC P-value")

Incidence<-Incidence[,c(1,2,4,6,3,5,7,8)]
head(Incidence)
#Incidence1<-Incidence[,c(1,2,4,6,3,5,7,8)]
write.csv(Incidence,"D:/zouyuping2023/task/GBD/Disease/RHD-2/以表格形式展示数据/result/204-new/result_RHD_DALYs.csv")
###27个地区时改变顺序

