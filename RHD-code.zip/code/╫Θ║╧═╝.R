#设置工作路径
setwd("D:/zouyuping2023/task/GBD/Disease/RHD-2/柱状图")
# 加载R包，没有安装请先安装  install.packages("包名") 
library(ggplot2)
library(reshape2)
library(data.table)
library(dplyr)
##设置工作路径 setwd("E:/GBD RA/数据")

# 读取双向柱形图数据文件
##读取男性数据
RA <- fread("RHD-regions.csv")
RA_Male <- subset(RA,RA$measure=="Incidence"&
                     RA$location=="Global"&
                     RA$sex=="Male"&
                     RA$metric=="Number"&
                     RA$year==2021&
                     RA$age!="<5 years"&
                     RA$age!="Age-standardized"&
                     RA$age!="All ages")
RA_Male <- RA_Male[,c(3,4,8,9,10)]
#对男性年龄进行排1
age_order <- c(16,17,18,19,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)#按照RA_male表Age列排序情况修改
RA_Male <- cbind(RA_Male,age_order)
RA_Male <- RA_Male[order(RA_Male$age_order),]
#n <- aggregate(val~age,data = df_Male,sum)
#sex <- rep("Male",20)
#df1 <- data.frame(sex)
#df_Male <- cbind(df1,n)


##读取女性数据
RA_Female <- subset(RA,RA$measure=="Incidence"&
               RA$location=="Global"&
               RA$sex=="Female"&
               RA$metric=="Number"&
               RA$year==2021&
               RA$age!="<5 years"&
               RA$age!="Age-standardized"&
                 RA$age!="All ages")
RA_Female <- RA_Female[,c(3,4,8,9,10)]
#对女性年龄进行排序
age_order <- c(16,17,18,19,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)#按照RA_Female表Age列排序情况修改
RA_Female <- cbind(RA_Female,age_order)
RA_Female <- RA_Female[order(RA_Female$age_order),]
#n1 <- aggregate(val~age,data = df_Female,sum)
#sex <- rep("Female",20)
#df2 <- data.frame(sex)
#df_Female <- cbind(df2,n1)
#合并男性和女性数据
#RA_Sex_Incidence<-RA_Male
RA_Sex_Incidence <- rbind(RA_Female,RA_Male)
RA_Sex_Incidence <- RA_Sex_Incidence[,-6]#如果没改动排序可注释掉这一行
RA_Sex_Incidence <- RA_Sex_Incidence %>% select("age","sex","val","upper","lower")
RA_Sex_Incidence$val <- round(RA_Sex_Incidence$val,2)
RA_Sex_Incidence$upper <- round(RA_Sex_Incidence$upper,2)
RA_Sex_Incidence$lower <- round(RA_Sex_Incidence$lower,2)
###修改年龄标签
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="5-9 years"] <- "5 to 9"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="10-14 years"] <- "10 to 14"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="15-19 years"] <- "15 to 19"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="20-24 years"] <- "20 to 24"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="25-29 years"] <- "25 to 29"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="30-34 years"] <- "30 to 34"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="35-39 years"] <- "35 to 39"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="40-44 years"] <- "40 to 44"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="45-49 years"] <- "45 to 49"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="50-54 years"] <- "50 to 54"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="55-59 years"] <- "55 to 59"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="60-64 years"] <- "60 to 64"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="65-69 years"] <- "65 to 69"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="70-74 years"] <- "70 to 74"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="75-79 years"] <- "75 to 79"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="80-84"] <- "80 to 84"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="85-89"] <- "85 to 89"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="90-94"] <- "90 to 94"
RA_Sex_Incidence$age[RA_Sex_Incidence$age=="95+ years"] <- "95 plus"

###柱状图置信区间


##row.names(RA_Sex_Incidence) <- RA_Sex_Incidence[,1]
#RA_Sex_Incidence <- RA_Sex_Incidence[,c(-2,-4)]
#colnames(RA_Sex_Incidence) <- c("Age","Male","Female")
#write.csv(RA_Sex_Incidence,"RA_Sex_Incidence.csv",row.names = T)
# 把数据转换成ggplot常用的类型（长数据）
#RA_Sex_Incidence = melt(RA_Sex_Incidence)                    # melt出自reshape2包
#head(RA_Sex_Incidence)                         # 查看转换完成的数据的前几行

# 绘图柱状图
mytheme <- theme(plot.title = element_text(face="bold.italic",size=14,color="brown"),
                 axis.title = element_text(face="bold.italic",size=13,color="brown"),
                 axis.text = element_text(face="bold",size=9,color="darkblue"),
                 panel.background = element_rect(fill="white",color="darkblue"),
                 panel.grid.major.y = element_blank(),
                 panel.grid.minor.y = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 legend.position = "top")
age_levels <- RA_Sex_Incidence$age[1:19]
RA_Sex_Incidence$age <- factor(RA_Sex_Incidence$age,levels = age_levels)
RA_Sex_Incidence$sex <- factor(RA_Sex_Incidence$sex,levels = c("Female","Male"))
#RA_Sex_Incidence$sex <- factor(RA_Sex_Incidence$sex,levels = c("Male"))

ggplot(RA_Sex_Incidence,aes(x=age,y=val,fill=sex))+
  geom_bar(position = "dodge",stat = "identity")+mytheme+
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1,size = rel(.9),))+
  labs(x="age (years)",y="Total Incidence cases (Number)")

###
RA_Male1 <- subset(RA,RA$measure=="Incidence"&
                    RA$location=="Global"&
                    RA$sex=="Male"&
                    RA$metric=="Rate"&
                    RA$year==2021&
                    RA$age!="<5 years"&
                    RA$age!="Age-standardized"&
                     RA$age!="All ages")
RA_Male1 <- RA_Male1[,c(3,4,8,9,10)]
age_order <- c(16,17,18,19,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
RA_Male1 <- cbind(RA_Male1,age_order)
RA_Male1 <- RA_Male1[order(RA_Male1$age_order),] 

RA_Female1 <- subset(RA,RA$measure=="Incidence"&
                      RA$location=="Global"&
                      RA$sex=="Female"&
                      RA$metric=="Rate"&
                      RA$year==2021&
                      RA$age!="<5 years"&
                      RA$age!="Age-standardized"&
                       RA$age!="All ages")
RA_Female1 <- RA_Female1[,c(3,4,8,9,10)]
#对女性年龄进行排序
age_order <- c(16,17,18,19,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
RA_Female1 <- cbind(RA_Female1,age_order)
RA_Female1 <- RA_Female1[order(RA_Female1$age_order),]
#合并男性和女性数据
#RA_Sex_Incidence1 <- RA_Male1
RA_Sex_Incidence1 <- rbind(RA_Female1,RA_Male1)
RA_Sex_Incidence1 <- RA_Sex_Incidence1[,-6]
RA_Sex_Incidence1 <- RA_Sex_Incidence1 %>% select("age","sex","val","upper","lower")
RA_Sex_Incidence1$val <- round(RA_Sex_Incidence1$val,2)
RA_Sex_Incidence1$upper <- round(RA_Sex_Incidence1$upper,2)
RA_Sex_Incidence1$lower <- round(RA_Sex_Incidence1$lower,2)
###修改年龄标签
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="5-9 years"] <- "5 to 9"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="10-14 years"] <- "10 to 14"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="15-19 years"] <- "15 to 19"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="20-24 years"] <- "20 to 24"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="25-29 years"] <- "25 to 29"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="30-34 years"] <- "30 to 34"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="35-39 years"] <- "35 to 39"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="40-44 years"] <- "40 to 44"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="45-49 years"] <- "45 to 49"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="50-54 years"] <- "50 to 54"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="55-59 years"] <- "55 to 59"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="60-64 years"] <- "60 to 64"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="65-69 years"] <- "65 to 69"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="70-74 years"] <- "70 to 74"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="75-79 years"] <- "75 to 79"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="80-84"] <- "80 to 84"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="85-89"] <- "85 to 89"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="90-94"] <- "90 to 94"
RA_Sex_Incidence1$age[RA_Sex_Incidence1$age=="95+ years"] <- "95 plus"

age_levels1 <- RA_Sex_Incidence1$age[1:19]
RA_Sex_Incidence1$age <- factor(RA_Sex_Incidence1$age,levels = age_levels1)
RA_Sex_Incidence1$sex <- factor(RA_Sex_Incidence1$sex,levels = c("Female","Male"))
#RA_Sex_Incidence1$sex <- factor(RA_Sex_Incidence1$sex,levels = c("Male"))
#折线图
ggplot(RA_Sex_Incidence1,aes(x=age,color=sex,group=sex))+
  mytheme+
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1,size = rel(.9),))+
  labs(x="age (years)",y="Incidence rate per 100,000 population")+
  geom_line(aes(y=upper),linetype="dashed")+
  geom_line(aes(y=lower),linetype="longdash",lwd=1.05)+
  geom_line(aes(y=val),lwd=1.05)

  
  
###组合图
colnames(RA_Sex_Incidence1) <- c("age","sex","val1","upper1","lower1")
RA_Sex_Incidence2 <- cbind(RA_Sex_Incidence,RA_Sex_Incidence1)
RA_Sex_Incidence2 <- RA_Sex_Incidence2[,c(-6,-7)]
age_levels2 <- RA_Sex_Incidence2$age[1:19]
RA_Sex_Incidence2$age <- factor(RA_Sex_Incidence2$age,levels = age_levels2)
#RA_Sex_Incidence2$sex <- factor(RA_Sex_Incidence2$sex,levels = c("Male","Female"))
RA_Sex_Incidence2$sex <- factor(RA_Sex_Incidence2$sex,levels = c("Female",'Male'))

scaleFactor <- max(RA_Sex_Incidence2$val)/max(RA_Sex_Incidence2$val1)

ggplot(RA_Sex_Incidence2,aes(x=age,color=sex,group=sex))+mytheme+
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1,size = rel(.9),))+
  labs(x="age (years)",y="Incidence rate per 100,000 population")+
  geom_bar(aes(y=val,fill=sex),position = "dodge",stat = "identity")+
  geom_errorbar(aes(ymin=lower,ymax=upper),position = position_dodge(0.9),width=.4,color="black",alpha=.8,size=1)+
  labs(y="Total Incidence cases (Number)")+
  geom_line(aes(y=upper1*scaleFactor),linetype="dashed")+
  geom_line(aes(y=lower1*scaleFactor),linetype="longdash",lwd=1.05)+
  geom_line(aes(y=val1*scaleFactor),lwd=1.05)+
  
  scale_y_continuous(sec.axis = sec_axis(~./scaleFactor,name = "Incidence rate per 100,000 population"))+
  
  theme(legend.title = element_blank(),legend.position = "top",legend.background = element_blank())+
  scale_color_discrete(labels=c("Female (Rate,95% Uncertainty Intervals)","Male (Rate,95% Uncertainty Intervals)"))+
  guides(fill=guide_legend(nrow = 2))+
  scale_fill_discrete(labels=c("Female (Number,95% Uncertainty Intervals)","Male (Number,95% Uncertainty Intervals)"))+
  guides(col=guide_legend(nrow = 2))
  



#修改incidence prevalence deaths dalys跑四遍  












