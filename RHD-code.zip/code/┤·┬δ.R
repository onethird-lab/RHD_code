setwd('E:\\GBD RA\\差异分析')
library(ggplot2)
library(patchwork)
library(lemon)
library(ggsignif)
library(ggsci)
RA <- read.csv("D:/zouyuping2023/task/GBD/Disease/RHD-2/SDI国家分组/RHD-Countries.csv")
SDI_country <- read.csv("D:/zouyuping2023/task/GBD/Disease/RHD-2/SDI国家分组/SDI国家分级1.csv")
### 调整SDI与RA里location命名一致
RA$location[RA$location == "Democratic People's Republic of Korea"] = 'North Korea'
RA$location[RA$location == 'Russian Federation'] = 'Russia'
RA$location[RA$location == 'United Kingdom'] = 'UK'
RA$location[RA$location == "Iran (Islamic Republic of)"] = 'Iran'
RA$location[RA$location == "Taiwan"] = 'Taiwan (Province of China)'
RA$location[RA$location == "Republic of Korea"] = 'South Korea'
RA$location[RA$location == "United Republic of Tanzania"] = 'Tanzania'
RA$location[RA$location == "Bolivia (Plurinational State of)"] = 'Bolivia'
RA$location[RA$location == "Venezuela (Bolivarian Republic of)"] = 'Venezuela'
RA$location[RA$location == "Czechia"] = 'Czech Republic'
RA$location[RA$location == "Republic of Moldova"] = 'Moldova'
RA$location[RA$location == "Viet Nam"] = 'Vietnam'
RA$location[RA$location == "Lao People's Democratic Republic"] = 'Laos'
RA$location[RA$location == "Syrian Arab Republic"] = 'Syria'
RA$location[RA$location == "North Macedonia"] = 'Macedonia'
RA$location[RA$location == "Brunei Darussalam"] = 'Brunei'
RA$location[RA$location == "Gambia"] = 'The Gambia'
RA$location[RA$location == "United States of America"] = 'USA'
RA$location[RA$location == "Micronesia (Federated States of)"] = 'Federated States of Micronesia'
RA$location[RA$location == "Bahamas"] = 'The Bahamas'
RA$location[RA$location == "United States Virgin Islands"] = 'Virgin Islands'
RA$location[RA$location == "Macedonia"] = 'North Macedonia'
RA$location[RA$location == 'Democratic Republic of the Congo'] = 'DR Congo'
RA$location[RA$location == 'Congo'] = 'Congo (Brazzaville)'
RA$location[RA$location == 'Cabo Verde'] = 'Cape Verde'
RA$location[RA$location == 'Sao Tome and Principe'] = 'São Tomé and PrÍncipe'
RA$location[RA$location == 'Eswatini'] = 'eSwatini'
RA$location[RA$location == "Türkiye"] = "Turkey"
###ASR
#ASPR
ASPR <- subset(RA,RA$measure=='Prevalence'&
                  RA$sex=='Both'&
                  RA$age=='Age-standardized'&
                  RA$metric=='Rate'&
                  RA$year==2021)
ASPR <- merge(ASPR,SDI_country,by='location')
ASPR <- ASPR[,c(1,8,12,13)]
mytheme <- theme(plot.title = element_text(face="bold.italic",size=14,color="brown"),
                 axis.title = element_text(face="bold.italic",size=13,color="brown"),
                 axis.text = element_text(face="bold",size=9,color="darkblue"),
                 panel.background = element_rect(fill="white",color="darkblue"),
                 panel.grid.major.y = element_blank(),
                 panel.grid.minor.y = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 legend.position = "top")
ASPR$levels <- factor(ASPR$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                   'Low-middle SDI','Low SDI'))

p1 <- ggplot(ASPR,aes(levels,val,color=levels))+
  geom_boxplot(aes(group=levels,color=levels))+
  mytheme+
  labs(y='ASPR (per 100,000)',x=NULL)+
  theme(legend.position = 'top',legend.box = "horizontal")+
  guides(color = guide_legend( nrow = 1,bycol=T))+
  scale_y_continuous(limits = c(0,4000))+
  geom_jitter(shape=16, position = position_jitter(0.2))+
  geom_signif(comparisons=list(c("High SDI","High-middle SDI"), c("High SDI","Middle SDI"), c("High SDI","Low-middle SDI"),
                               c('High SDI','Low SDI'),c('High-middle SDI','Middle SDI'),c('High-middle SDI','Low-middle SDI'),
                               c('High-middle SDI','Low SDI'),c('Middle SDI','Low-middle SDI'),c('Middle SDI','Low SDI'),
                               c('Low-middle SDI','Low SDI')), 
              textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
  #guides(color=guide_legend(nrow = 3))
p1


mycompare <- list(c("High SDI","High-middle SDI"), c("High SDI","Middle SDI"), c("High SDI","Low-middle SDI"),
     c('High SDI','Low SDI'),c('High-middle SDI','Middle SDI'),c('High-middle SDI','Low-middle SDI'),
     c('High-Middle SDI','Low SDI'),c('Middle SDI','Low-middle SDI'),c('Middle SDI','Low SDI'),c('Low-middle SDI','Low SDI'))

#ASIR
ASIR <- subset(RA,RA$measure=='Incidence'&
                  RA$sex=='Both'&
                  RA$age=='Age-standardized'&
                  RA$metric=='Rate'&
                  RA$year==2021)
ASIR <- merge(ASIR,SDI_country,by='location')
ASIR <- ASIR[,c(1,8,12,13)]
ASIR$levels <- factor(ASIR$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                             'Low-middle SDI','Low SDI'))
p2 <- ggplot(ASIR,aes(levels,val,color=levels))+
  geom_boxplot(aes(group=levels,color=levels))+
  mytheme+
  labs(y='ASIR (per 100,000)',x=NULL)+
  theme(legend.position = 'none')+
  scale_y_continuous(limits = c(0,300))+
  geom_jitter(shape=16, position = position_jitter(0.2))+
  geom_signif(comparisons=list(c("High SDI","High-middle SDI"), c("High SDI","Middle SDI"), c("High SDI","Low-middle SDI"),
                               c('High SDI','Low SDI'),c('High-middle SDI','Middle SDI'),c('High-middle SDI','Low-middle SDI'),
                               c('High-middle SDI','Low SDI'),c('Middle SDI','Low-middle SDI'),c('Middle SDI','Low SDI'),
                               c('Low-middle SDI','Low SDI')), 
              textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p2

#DALYs
ASDR <- subset(RA,RA$measure=='DALYs (Disability-Adjusted Life Years)'&
                 RA$sex=='Both'&
                 RA$age=='Age-standardized'&
                 RA$metric=='Rate'&
                 RA$year==2021)
ASDR <- merge(ASDR,SDI_country,by='location')
ASDR <- ASDR[,c(1,8,12,13)]
ASDR$levels <- factor(ASDR$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                             'Low-middle SDI','Low SDI'))

p3 <- ggplot(ASDR,aes(levels,val,color=levels))+
  geom_boxplot(aes(group=levels,color=levels))+
  mytheme+
  labs(y='ASDR DALYs (per 100,000)',x=NULL)+
  theme(legend.position = 'none')+
  scale_y_continuous(limits = c(0,1200))+
  geom_jitter(shape=16, position = position_jitter(0.2))+
  geom_signif(comparisons=list(c("High SDI","High-middle SDI"), c("High SDI","Middle SDI"), c("High SDI","Low-middle SDI"),
                               c('High SDI','Low SDI'),c('High-middle SDI','Middle SDI'),c('High-middle SDI','Low-middle SDI'),
                               c('High-middle SDI','Low SDI'),c('Middle SDI','Low-middle SDI'),c('Middle SDI','Low SDI'),
                               c('Low-middle SDI','Low SDI')), 
              textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p3
#Deaths
ASDeR <- subset(RA,RA$measure=='Deaths'&
                 RA$sex=='Both'&
                 RA$age=='Age-standardized'&
                 RA$metric=='Rate'&
                 RA$year==2021)
ASDeR <- merge(ASDeR,SDI_country,by='location')
ASDeR <- ASDeR[,c(1,8,12,13)]
ASDeR$levels <- factor(ASDeR$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                             'Low-middle SDI','Low SDI'))

p4 <- ggplot(ASDeR,aes(levels,val,color=levels))+
  geom_boxplot(aes(group=levels,color=levels))+
  mytheme+
  labs(y='ASDR Deaths (per 100,000)',x=NULL)+
  theme(legend.position = 'none')+
  scale_y_continuous(limits = c(0,40))+
  geom_jitter(shape=16, position = position_jitter(0.2))+
  geom_signif(comparisons=list(c("High SDI","High-middle SDI"), c("High SDI","Middle SDI"), c("High SDI","Low-middle SDI"),
                               c('High SDI','Low SDI'),c('High-middle SDI','Middle SDI'),c('High-middle SDI','Low-middle SDI'),
                               c('High-middle SDI','Low SDI'),c('Middle SDI','Low-middle SDI'),c('Middle SDI','Low SDI'),
                               c('Low-middle SDI','Low SDI')), 
              textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p4

library(ggpubr)
combined_plot <- ggarrange(p1,p2,p3,p4,ncol = 2,nrow = 2,common.legend = T)

p5 <- p1+p2+p3+p4
p5

##sex
RA_Prevalence <- subset(RA,RA$measure=='Prevalence'&
                           RA$sex%in%c('Female','Male')&
                           RA$age=='Age-standardized'&
                           RA$metric=='Rate'&
                           RA$year==2021)
RA_Prevalence <- merge(RA_Prevalence,SDI_country,by='location')
RA_Prevalence <- RA_Prevalence[,c(1,3,8,13)]
RA_Prevalence$sex <- factor(RA_Prevalence$sex,levels = c('Female','Male'))
RA_Prevalence$levels <- factor(RA_Prevalence$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                      'Low-middle SDI','Low SDI'))


p6 <- ggplot(RA_Prevalence,aes(sex,val,color=sex))+
  mytheme+
  geom_boxplot()+
  theme(legend.position = 'none')+
  geom_jitter(shape=16, position = position_jitter(0.2),size=1)+
  labs(y='ASPR (per 100,000)')+
  geom_signif(comparisons = list(c('Female','Male')),textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p6  
#Incidence
RA_Incidence <- subset(RA,RA$measure=='Incidence'&
                          RA$sex%in%c('Female','Male')&
                          RA$age=='Age-standardized'&
                          RA$metric=='Rate'&
                          RA$year==2021)
RA_Incidence <- merge(RA_Incidence,SDI_country,by='location')
RA_Incidence <- RA_Incidence[,c(1,3,8,13)]
RA_Incidence$sex <- factor(RA_Incidence$sex,levels = c('Female','Male'))
RA_Incidence$levels <- factor(RA_Incidence$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                               'Low-middle SDI','Low SDI'))


p7 <- ggplot(RA_Incidence,aes(sex,val,color=sex))+
  mytheme+
  geom_boxplot()+
  theme(legend.position = 'top')+
  geom_jitter(shape=16, position = position_jitter(0.2),size=1)+
  labs(y='ASIR (per 100,000)')+
  geom_signif(comparisons = list(c('Female','Male')),textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p7  

#DALYs
RA_DALYs <- subset(RA,RA$measure=='DALYs (Disability-Adjusted Life Years)'&
                         RA$sex%in%c('Female','Male')&
                         RA$age=='Age-standardized'&
                         RA$metric=='Rate'&
                         RA$year==2021)
RA_DALYs <- merge(RA_DALYs,SDI_country,by='location')
RA_DALYs <- RA_DALYs[,c(1,3,8,13)]
RA_DALYs$sex <- factor(RA_DALYs$sex,levels = c('Female','Male'))
RA_DALYs$levels <- factor(RA_DALYs$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                             'Low-middle SDI','Low SDI'))


p8 <- ggplot(RA_DALYs,aes(sex,val,color=sex))+
  mytheme+
  geom_boxplot()+
  theme(legend.position = 'none')+
  geom_jitter(shape=16, position = position_jitter(0.2),size=1)+
  labs(y='ASDR (per 100,000)')+
  geom_signif(comparisons = list(c('Female','Male')),textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p8

#Deaths
RA_Deaths <- subset(RA,RA$measure=='Deaths'&
                     RA$sex%in%c('Female','Male')&
                     RA$age=='Age-standardized'&
                     RA$metric=='Rate'&
                     RA$year==2021)
RA_Deaths <- merge(RA_Deaths,SDI_country,by='location')
RA_Deaths <- RA_Deaths[,c(1,3,8,13)]
RA_Deaths$sex <- factor(RA_Deaths$sex,levels = c('Female','Male'))
RA_Deaths$levels <- factor(RA_Deaths$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                     'Low-middle SDI','Low SDI'))


p9 <- ggplot(RA_Deaths,aes(sex,val,color=sex))+
  mytheme+
  geom_boxplot()+
  theme(legend.position = 'none')+
  geom_jitter(shape=16, position = position_jitter(0.2),size=1)+
  labs(y='ASDeR (per 100,000)')+
  geom_signif(comparisons = list(c('Female','Male')),textsize = 3, test='t.test', step_increase=0.1, map_signif_level=T,stat = 'signif')
p9


combined_plot1 <- ggarrange(p6,p7,p8,p9,ncol = 2,nrow = 2,common.legend = T)
p10 <- p6+p7+p8+p9
p10


