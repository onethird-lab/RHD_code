setwd("D:/zouyuping2023/task/GBD/Disease/RHD-2/SDI影响")
library(data.table)
library(reshape2)
library(ggplot2)
library(gridExtra)
install.packages('ggthemes')
library(ggthemes)
library(patchwork)
library(lemon)
library(ggpubr)

RA <- fread("RHD-regions.csv")
###5个按社会发展指数划分地区的折线图
RA_All <- subset(RA,RA$location%in%c("High SDI","High-middle SDI","Middle SDI",
                                         "Low-middle SDI","Global","Low SDI")&
                    RA$metric=="Rate"&
                    RA$age=="Age-standardized")
RA_All$location <- factor(RA_All$location,levels = c("Global","High SDI","High-middle SDI",
                                             "Middle SDI","Low-middle SDI","Low SDI"))
RA_All$year <- factor(RA_All$year,levels = sort(unique(RA_All$year)))

mytheme <- theme(plot.title = element_text(face="bold.italic",size=14,color="brown",hjust = .5,vjust = .5),
                 axis.title = element_text(face="bold.italic",size=13,color="brown"),
                 axis.text = element_text(face="bold",size=9,color="darkblue"),
                 panel.background = element_rect(fill="white",color="darkblue"),
                 panel.grid.major.y = element_blank(),
                 panel.grid.minor.y = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 legend.position = "top",
                 legend.title = element_blank())





RA_All$measure <- factor(RA_All$measure,levels = c("DALYs (Disability-Adjusted Life Years)","Deaths","Incidence","Prevalence"))
RA_All$location <- factor(RA_All$location,levels = c("Global","High SDI","High-middle SDI",
                                                     "Middle SDI","Low-middle SDI","Low SDI"))
RA_All$sex <- factor(RA_All$sex,levels = c("Both","Male","Female"))
RA_All$year <- factor(RA_All$year,levels = sort(unique(RA_All$year)))


ggplot(RA_All,aes(x=year,y=val,group=location))+
  geom_line(aes(color=location,linetype=location),size=1)+
  facet_rep_wrap(measure~sex,scales = "free_y", repeat.tick.labels = 'left')+
  mytheme+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  theme(axis.text.x = element_text(),strip.text.x = element_blank(),
        legend.key = element_blank())+
  guides(color=guide_legend(direction = "horizontal"))
####
RA_Prevalence_Both <- subset(RA_All,RA_All$measure=="Prevalence"&
                                    RA_All$sex=="Both")
p1 <- ggplot(RA_Prevalence_Both,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(title = "Male and Female",y="ASPR")+
  xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p1


RA_Prevalence_Male <- subset(RA_All,RA_All$measure=="Prevalence"&
                                    RA_All$sex=="Male")
p2 <- ggplot(RA_Prevalence_Male,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(title = "Male")+
  ylab(NULL)+xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p2

RA_Prevalence_Female <- subset(RA_All,RA_All$measure=="Prevalence"&
                                      RA_All$sex=="Female")
p3 <- ggplot(RA_Prevalence_Female,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(title = "Female")+
  ylab(NULL)+xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p3


RA_Incidence_Both <- subset(RA_All,RA_All$measure=="Incidence"&
                                   RA_All$sex=="Both")
p4 <- ggplot(RA_Incidence_Both,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASIR")+
  xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p4
RA_Incidence_Male <- subset(RA_All,RA_All$measure=="Incidence"&
                                   RA_All$sex=="Male")
p5 <- ggplot(RA_Incidence_Male,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASIR")+
  ylab(NULL)+xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p5
RA_Incidence_Female <- subset(RA_All,RA_All$measure=="Incidence"&
                                     RA_All$sex=="Female")
p6 <- ggplot(RA_Incidence_Female,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASIR")+
  ylab(NULL)+xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p6

RA_DALYs_Both <- subset(RA_All,RA_All$measure=="DALYs (Disability-Adjusted Life Years)"&
                               RA_All$sex=="Both")
p7 <- ggplot(RA_DALYs_Both,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASDR")+
  xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p7 
RA_DALYs_Male <- subset(RA_All,RA_All$measure=="DALYs (Disability-Adjusted Life Years)"&
                               RA_All$sex=="Male") 
p8 <- ggplot(RA_DALYs_Male,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASDR")+
  ylab(NULL)+xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p8
RA_DALYs_Female <- subset(RA_All,RA_All$measure=="DALYs (Disability-Adjusted Life Years)"&
                                 RA_All$sex=="Female") 
p9 <- ggplot(RA_DALYs_Female,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASDR")+
  ylab(NULL)+xlab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p9

RA_Deaths_Both <- subset(RA_All,RA_All$measure=="Deaths"&
                           RA_All$sex=="Both")
p10 <- ggplot(RA_Deaths_Both,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASDeR")+guides(color=guide_legend(byrow = T,nrow  = 1))
p10
RA_Deaths_Male <- subset(RA_All,RA_All$measure=="Deaths"&
                           RA_All$sex=="Male")
p11 <- ggplot(RA_Deaths_Male,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASDeR")+
  ylab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p11
RA_Deaths_Female <- subset(RA_All,RA_All$measure=="Deaths"&
                             RA_All$sex=="Female")
p12 <- ggplot(RA_Deaths_Female,aes(x=year,y=val,color=location,group=location))+
  geom_line(aes(linetype=location),size=1)+
  mytheme+
  scale_x_discrete(breaks = c(1990,1998,2006,2014,2021))+
  scale_color_manual(values = c("#3cb346","#00abf0","#d75427","#2e409a","#942d8d","#eeb401"))+
  theme(legend.position = "top",axis.title.y = element_text(size=13),
        legend.key = element_blank(),legend.text = element_text(size=7))+
  labs(y="ASDeR")+
  ylab(NULL)+guides(color=guide_legend(byrow = T,nrow  = 1))
p12




###计算AAPCs的方法
#Prevalence
RA_A <- RA
RA_A$A <- paste(RA_A$location,RA_A$sex,sep = "-")
colnames(RA_A)[11] <- "Location"
RA_A <- RA_A[,c(11,1:10)]
AAPC_Prevalence <- subset(RA_A,RA_A$measure=="Prevalence"&
                               RA_A$age=="Age-standardized"&
                               RA_A$metric=="Rate")
AAPC_Prevalence$val <- round(AAPC_Prevalence$val,digits = 2)
AAPC_Prevalence$lower <- round(AAPC_Prevalence$lower,digits = 2)
AAPC_Prevalence$upper <- round(AAPC_Prevalence$upper,digits = 2)
AAPC_Prevalence <- AAPC_Prevalence[,c(1,8,9,10,11)]
AAPC_Prevalence$SE <- (AAPC_Prevalence$upper-AAPC_Prevalence$lower)/(1.96*2)
AAPC_Prevalence <- AAPC_Prevalence[,c(1,2,3,6)]
AAPC_Prevalence <- AAPC_Prevalence[order(AAPC_Prevalence$Location,AAPC_Prevalence$year),]
write.csv(AAPC_Prevalence,'AAPC_Prevalence.csv',row.names = F)
unique(AAPC_Prevalence$Location)

Prevalence_AAPC <- read.table('Prevalence-RHD-AAPC.txt',header = T)
###加上一列measure
measure <- c(rep("Prevalence",81))
Prevalence_AAPC <- cbind(Prevalence_AAPC,measure)
###加上一列性别
sex <- rep(c("Both","Female","Male"),27)
Prevalence_AAPC <- cbind(Prevalence_AAPC,sex)
###排序
Prevalence_AAPC <- Prevalence_AAPC[order(Prevalence_AAPC$Location),]
###加一列地点
location <- rep(sort(unique(RA$location)),each=3)
Prevalence_AAPC <- cbind(Prevalence_AAPC,location)
Prevalence_AAPC <- Prevalence_AAPC[,c(12,13,14,6,7,8)]
colnames(Prevalence_AAPC)[4:6] <- c('AAPC','lower','upper')


#Incidence
RA_B <- RA
RA_B$A <- paste(RA_B$location,RA_B$sex,sep = "-")
colnames(RA_B)[11] <- "Location"
RA_B <- RA_B[,c(11,1:10)]
AAPC_Incidence <- subset(RA_B,RA_B$measure=="Incidence"&
                              RA_B$age=="Age-standardized"&
                              RA_B$metric=="Rate")
AAPC_Incidence$val <- round(AAPC_Incidence$val,digits = 2)
AAPC_Incidence$lower <- round(AAPC_Incidence$lower,digits = 2)
AAPC_Incidence$upper <- round(AAPC_Incidence$upper,digits = 2)
AAPC_Incidence <- AAPC_Incidence[,c(1,8,9,10,11)]
AAPC_Incidence$SE <- (AAPC_Incidence$upper-AAPC_Incidence$lower)/(1.96*2)
AAPC_Incidence <- AAPC_Incidence[,c(1,2,3,6)]
AAPC_Incidence <- AAPC_Incidence[order(AAPC_Incidence$Location,AAPC_Incidence$year),]
write.csv(AAPC_Incidence,'AAPC_Incidence.csv',row.names = F)

Incidence_AAPC <- read.table('Incidence-RHD-AAPC.txt',header = T)

###加上一列measure
measure <- c(rep("Incidence",81))
Incidence_AAPC <- cbind(Incidence_AAPC,measure)
###加上一列性别
sex <- rep(c("Both","Female","Male"),27)
Incidence_AAPC <- cbind(Incidence_AAPC,sex)
###排序
Incidence_AAPC <- Incidence_AAPC[order(Incidence_AAPC$Location),]
###加一列地点
location <- rep(sort(unique(RA$location)),each=3)
Incidence_AAPC <- cbind(Incidence_AAPC,location)
Incidence_AAPC <- Incidence_AAPC[,c(12,13,14,6,7,8)]
colnames(Incidence_AAPC)[4:6] <- c('AAPC','lower','upper')


###DALYs
RA_C <- RA
RA_C$A <- paste(RA_C$location,RA_C$sex,sep = "-")
colnames(RA_C)[11] <- "Location"
RA_C <- RA_C[,c(11,1:10)]
AAPC_DALYs <- subset(RA_C,RA_C$measure=="DALYs (Disability-Adjusted Life Years)"&
                          RA_C$age=="Age-standardized"&
                          RA_C$metric=="Rate")
AAPC_DALYs$val <- round(AAPC_DALYs$val,digits = 2)
AAPC_DALYs$lower <- round(AAPC_DALYs$lower,digits = 2)
AAPC_DALYs$upper <- round(AAPC_DALYs$upper,digits = 2)
AAPC_DALYs <- AAPC_DALYs[,c(1,8,9,10,11)]
AAPC_DALYs$SE <- (AAPC_DALYs$upper-AAPC_DALYs$lower)/(1.96*2)
AAPC_DALYs <- AAPC_DALYs[,c(1,2,3,6)]
AAPC_DALYs <- AAPC_DALYs[order(AAPC_DALYs$Location,AAPC_DALYs$year),]
write.csv(AAPC_DALYs,'AAPC_DALYs.csv',row.names = F)

DALYs_AAPC <- read.table('DALYs-RHD-AAPC.txt',header = T)

###加上一列measure
measure <- c(rep("DALYs",81))
DALYs_AAPC <- cbind(DALYs_AAPC,measure)
###加上一列性别
sex <- rep(c("Both","Female","Male"),27)
DALYs_AAPC <- cbind(DALYs_AAPC,sex)
###排序
DALYs_AAPC <- DALYs_AAPC[order(DALYs_AAPC$Location),]
###加一列地点
location <- rep(sort(unique(RA$location)),each=3)
DALYs_AAPC <- cbind(DALYs_AAPC,location)
DALYs_AAPC <- DALYs_AAPC[,c(12,13,14,6,7,8)]
colnames(DALYs_AAPC)[4:6] <- c('AAPC','lower','upper')

#Deaths
RA_D <- RA
RA_D$A <- paste(RA_D$location,RA_D$sex,sep = "-")
colnames(RA_D)[11] <- "Location"
RA_D <- RA_D[,c(11,1:10)]
AAPC_Deaths <- subset(RA_D,RA_D$measure=="Deaths"&
                        RA_D$age=="Age-standardized"&
                        RA_D$metric=="Rate")
AAPC_Deaths$val <- round(AAPC_Deaths$val,digits = 2)
AAPC_Deaths$lower <- round(AAPC_Deaths$lower,digits = 2)
AAPC_Deaths$upper <- round(AAPC_Deaths$upper,digits = 2)
AAPC_Deaths <- AAPC_Deaths[,c(1,8,9,10,11)]
AAPC_Deaths$SE <- (AAPC_Deaths$upper-AAPC_Deaths$lower)/(1.96*2)
AAPC_Deaths <- AAPC_Deaths[,c(1,2,3,6)]
AAPC_Deaths <- AAPC_Deaths[order(AAPC_Deaths$Location,AAPC_Deaths$year),]
write.csv(AAPC_Deaths,'AAPC_Deaths.csv',row.names = F)

Deaths_AAPC <- read.table('Deaths-RHD-AAPC.txt',header = T)
###加上一列measure
measure <- c(rep("Deaths",81))
Deaths_AAPC <- cbind(Deaths_AAPC,measure)
###加上一列性别
sex <- rep(c("Both","Female","Male"),27)
Deaths_AAPC <- cbind(Deaths_AAPC,sex)
###排序
Deaths_AAPC <- Deaths_AAPC[order(Deaths_AAPC$Location),]
###加一列地点
location <- rep(sort(unique(RA$location)),each=3)
Deaths_AAPC <- cbind(Deaths_AAPC,location)
Deaths_AAPC <- Deaths_AAPC[,c(12,13,14,6,7,8)]
colnames(Deaths_AAPC)[4:6] <- c('AAPC','lower','upper')


###合并所有数据
AAPCs <- rbind(Prevalence_AAPC,Incidence_AAPC)
AAPCs <- rbind(AAPCs,DALYs_AAPC)
AAPCs <- rbind(AAPCs,Deaths_AAPC)
###作图
AAPCs_SDI <- subset(AAPCs,AAPCs$location%in%c("Global","High SDI","High-middle SDI",
                                               "Middle SDI","Low-middle SDI","Low SDI"))
AAPCs_SDI$location <- factor(AAPCs_SDI$location,levels = c("Global","High SDI","High-middle SDI",
                                                   "Middle SDI","Low-middle SDI","Low SDI"))
AAPCs_SDI$measure <- factor(AAPCs_SDI$measure,levels = c("Prevalence","Incidence","DALYs","Deaths"))
AAPCs_SDI$sex <- factor(AAPCs_SDI$sex,levels = c("Both","Male","Female"))


# p_EAPCs <- ggplot(EAPCs_SDI,aes(x=locations,y=EAPC,fill=measure))+
#   mytheme+
#   geom_bar(position = "dodge",stat = "identity")+
#   facet_grid(.~sex)+
#   scale_fill_manual(values = c("#e20612","#ffd401","#00b0ed"),labels=c("Age-standardized prevalence rate","Age-standardized incidence rate",
#                                                                        "Age-standardized DALYs rate"))+
#   theme(legend.position = "top")+
#   labs(y="EAPCs",x="Sociodemographic index")+
#   theme(strip.text.x = element_blank() )+
#   geom_errorbar(aes(ymin=LUI,ymax=UUI),position=position_dodge(width=0.90),width=.4,
#                 color="black",alpha=.8,size=.8)+
#   scale_x_discrete(labels=c("Global","High","High-\nmiddle","Middle","Low-\nmiddle","Low"))
# p_EAPCs


AAPCs_SDI_Both <- subset(AAPCs_SDI,AAPCs_SDI$sex=="Both")


p13 <- ggplot(AAPCs_SDI_Both,aes(x=location,y=AAPC,fill=measure))+
  geom_bar(position = "dodge",stat = "identity")+
  scale_fill_manual(values = c("#e20612","#ffd401","#00b0ed","#17b978"),
                    labels=c("Age-standardized prevalence rate",
                             "Age-standardized incidence rate",
                             "Age-standardized DALYs rate",
                             "Age-standardized Deaths rate"))+
  geom_errorbar(aes(ymin=lower,ymax=upper),position=position_dodge(width=0.90),width=.4,
                color="black",alpha=.8,size=.8)+
  mytheme+
  labs(y="AAPCs",x="Sociodemographic index")+
  theme(legend.position = "none",legend.key.size = unit(6, "pt"))+
  scale_x_discrete(labels=c("Global","High","High-\nmiddle","Middle","Low-\nmiddle","Low"))
p13
                         
                         
AAPCs_SDI_Male <- subset(AAPCs_SDI,AAPCs_SDI$sex=="Male")

p14 <- ggplot(AAPCs_SDI_Male,aes(x=location,y=AAPC,fill=measure))+
  geom_bar(position = "dodge",stat = "identity")+
  scale_fill_manual(values = c("#e20612","#ffd401","#00b0ed","#17b978"),
                    labels=c("Age-standardized prevalence rate",
                             "Age-standardized incidence rate",
                             "Age-standardized DALYs rate",
                             "Age-standardized Deaths rate"))+
  geom_errorbar(aes(ymin=lower,ymax=upper),position=position_dodge(width=0.90),width=.4,
                color="black",alpha=.8,size=.8)+
  mytheme+
  labs(y="AAPCs",x="Sociodemographic index")+
  ylab(NULL)+
  theme(legend.position = "none",legend.text = element_text(size=7),legend.key.size = unit(6, "pt"))+
  scale_x_discrete(labels=c("Global","High","High-\nmiddle","Middle","Low-\nmiddle","Low"))
p14                        
                         
AAPCs_SDI_Female <- subset(AAPCs_SDI,AAPCs_SDI$sex=="Female")

p15 <- ggplot(AAPCs_SDI_Female,aes(x=location,y=AAPC,fill=measure))+
  geom_bar(position = "dodge",stat = "identity")+
  scale_fill_manual(values = c("#e20612","#ffd401","#00b0ed","#17b978"),
                    labels=c("Age-standardized prevalence rate",
                             "Age-standardized incidence rate",
                             "Age-standardized DALYs rate",
                             "Age-standardized Deaths rate"))+
  geom_errorbar(aes(ymin=lower,ymax=upper),position=position_dodge(width=0.90),width=.4,
                color="black",alpha=.8,size=.8)+
  mytheme+
  theme(legend.text = element_text(size=9),legend.key.size = unit(6, "pt"))+
  labs(y="AAPCs",x="Sociodemographic index")+
  ylab(NULL)+
  theme(legend.position = "none")+
  scale_x_discrete(labels=c("Global","High","High-\nmiddle","Middle","Low-\nmiddle","Low"))

p15                           



p16<-ggarrange(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,ncol = 3,nrow = 4,common.legend = T,legend ="top")
p16
p17 <- ggarrange(p13, p14, p15,ncol = 3, nrow = 1, common.legend = TRUE, legend = "top")
p17

p18 <- ggarrange(p16, p17, ncol = 1, nrow = 2,heights=c(4,1))

#p18 <- p1+p2+p3+p4+p5+p6+p7+p8+p9+p10+p11+p12+p13+p14+p15+plot_layout(ncol=3,nrow = 5)
p18

ggsave("P18.pdf",p18,width = 16, height = 13, units = "in")

dev.off






# 合并图形
p17 <- ggarrange(p13, p14, p15, labels = custom_labels,
                 ncol = 3, nrow = 1, common.legend = TRUE, legend = "top")

p17













