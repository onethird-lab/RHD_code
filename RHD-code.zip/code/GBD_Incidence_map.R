setwd("D:/zouyuping2023/task/GBD/世界地图绘图代码/") ##设置工作路径
#加载需要的包
library(ggplot2)
library(ggmap)
library(rgdal)
library(maps)
library(dplyr)
#读取2019年RA的Age-standardized Rate(ASR)
RA <- read.csv('RA-Countries.csv',header = T)  ## 读取我们的数据
ASR_2019 <- subset(RA,RA$year==2019 & 
                      RA$age=='Age-standardized' & 
                      RA$metric== 'Rate' &
                      RA$measure=='DALYs (Disability-Adjusted Life Years)'&
                      RA$sex=="Both") ## 获取2019年RA年龄校正后伤残调整生命年
ASR_2019 <- ASR_2019[,c(2,8,9,10)] #提取国家地点、数值及其上下区间
ASR_2019$val <- round(ASR_2019$val,1) ###保留一位小数点
ASR_2019$lower <- round(ASR_2019$lower,1) ###保留一位小数点
ASR_2019$upper <- round(ASR_2019$upper,1) ###保留一位小数点

####  map for ASR
worldData <- map_data('world')#引入世界地图数据,里面包含国家名称以及经纬度
country_asr <- ASR_2019
country_asr$location <- as.character(country_asr$location) 
###以下代码的目的是让country_asr$location的国家名称与worldData的国家名称一致
### 这样才能让数据映射到地图上
country_asr$location[country_asr$location =="Taiwan (Province of China)"] = 'Taiwan'
country_asr$location[country_asr$location =="Micronesia (Federated States of)"]="Micronesia"
country_asr$location[country_asr$location =="Lao People's Democratic Republic"]="Laos"
country_asr$location[country_asr$location =="Czechia"]="Czech Republic"
country_asr$location[country_asr$location =="Democratic People's Republic of Korea"]="North Korea"
country_asr$location[country_asr$location =="Viet Nam"]="Vietnam"
country_asr$location[country_asr$location =="Republic of Korea"]="South Korea"
country_asr$location[country_asr$location =="Brunei Darussalam"]="Brunei" 
country_asr$location[country_asr$location =="Russian Federation"]="Russia"
country_asr$location[country_asr$location == "Antigua and Barbuda"] = 'Antigua'
country_asr$location[country_asr$location == "Republic of Moldova"] = 'Moldova'
country_asr$location[country_asr$location == 'United States of America'] = 'USA'
country_asr$location[country_asr$location == "Venezuela (Bolivarian Republic of)"] = 'Venezuela'
country_asr$location[country_asr$location == "Trinidad and Tobago"] = 'Trinidad'
country_asr$location[country_asr$location == 'United Kingdom'] = 'UK'
country_asr$location[country_asr$location == "Bolivia (Plurinational State of)"] = 'Bolivia'
country_asr$location[country_asr$location == "Saint Vincent and the Grenadines"] = 'Saint Vincent'
country_asr$location[country_asr$location == "Syrian Arab Republic"] = 'Syria'
country_asr$location[country_asr$location == "Iran (Islamic Republic of)"] = 'Iran'
country_asr$location[country_asr$location == 'Congo'] = 'Republic of Congo'
country_asr$location[country_asr$location =="Côte d'Ivoire"]="Ivory Coast"
country_asr$location[country_asr$location == "Eswatini"] = 'Swaziland'
country_asr$location[country_asr$location == "Cabo Verde"] = 'Cape Verde'
country_asr$location[country_asr$location == "Saint Kitts and Nevis"] = 'Saint Kitts'
country_asr$location[country_asr$location == "United Republic of Tanzania"] = 'Tanzania'
country_asr$location[country_asr$location == "United States Virgin Islands"] = 'Virgin Islands'
#删除两个未在worldData中出现的国家“Tokelau”，“Tuvalu”
country_asr <- country_asr [-which(country_asr$location %in% c("Tokelau", "Tuvalu")),]

worldData <- map_data('world')
total <- full_join(worldData,country_asr,by = c('region'='location'))

p <- ggplot()

total <- total %>% mutate(val2=cut(val,breaks = c(10,15,30,45,60,100),
                               labels = c('10~15','15~30','30~45','45~60','60+'),
                                   include.lowest = T,right = T))

p2 <- p + geom_polygon(data=total, 
                       aes(x=long, y=lat, group = group,fill=val2),
                       colour="black",size = .2) + 
  scale_fill_brewer(palette = "Reds")+
  theme_void()+labs(x="", y="")+
  guides(fill = guide_legend(title='ASR(/10^5)'))+
  theme(legend.position = 'right')
p2


###90年至19年病例变化情况
####在GBD数据库中，Year一栏选择打开“Annual rate of change”，可获得相应数据
RA_Change <- read.csv('RA-Countries-Change.csv')
RA_Change_DALYs <- subset(RA_Change,RA_Change$measure=='DALYs (Disability-Adjusted Life Years)'&
                                         RA_Change$sex=='Both'&
                                         RA_Change$metric=="Number"&
                                         RA_Change$age=='All ages')
RA_Change_DALYs <- RA_Change_DALYs[,c(2,9)]
RA_Change_DALYs$val <- RA_Change_DALYs$val*100
country_case <- RA_Change_DALYs

country_case$location <- as.character(country_case$location) 
country_case$location[country_case$location == "Taiwan (Province of China)"] = 'Taiwan'
country_case$location[country_case$location =="Micronesia (Federated States of)"]="Micronesia"
country_case$location[country_case$location =="Lao People's Democratic Republic"]="Laos"
country_case$location[country_case$location =="Czechia"]="Czech Republic"
country_case$location[country_case$location =="Democratic People's Republic of Korea"]="North Korea"
country_case$location[country_case$location =="Viet Nam"]="Vietnam"
country_case$location[country_case$location =="Republic of Korea"]="South Korea"
country_case$location[country_case$location =="Brunei Darussalam"]="Brunei" 
country_case$location[country_case$location =="Russian Federation"]="Russia"
country_case$location[country_case$location == "Antigua and Barbuda"] = 'Antigu'
country_case$location[country_case$location == "Republic of Moldova"] = 'Moldova'
country_case$location[country_case$location == 'United States of America'] = 'USA'
country_case$location[country_case$location == "Venezuela (Bolivarian Republic of)"] = 'Venezuela'
country_case$location[country_case$location == "Trinidad and Tobago"] = 'Trinidad'
country_case$location[country_case$location == 'United Kingdom'] = 'UK'
country_case$location[country_case$location == "Bolivia (Plurinational State of)"] = 'Bolivia'
country_case$location[country_case$location == "Saint Vincent and the Grenadines"] = 'Saint Vincent'
country_case$location[country_case$location == "Syrian Arab Republic"] = 'Syria'
country_case$location[country_case$location == "Iran (Islamic Republic of)"] = 'Iran'
country_case$location[country_case$location == 'Congo'] = 'Republic of Congo'
country_case$location[country_case$location =="Côte d'Ivoire"]="Ivory Coast"
country_case$location[country_case$location == "Eswatini"] = 'Swaziland'
country_case$location[country_case$location == "Cabo Verde"] = 'Cape Verde'
country_case$location[country_case$location == "Saint Kitts and Nevis"] = 'Saint Kitts'
country_case$location[country_case$location == "United Republic of Tanzania"] = 'Tanzania'
country_case$location[country_case$location == "United States Virgin Islands"] = 'Virgin Islands'
#删除两个未在worldData中出现的国家
country_case <- country_case[-which(country_case$location %in% c("Tokelau", "Tuvalu")),]

worldData <- map_data('world')
total <- full_join(worldData,country_case,by = c('region'='location'))

p <- ggplot()

total <- total %>% mutate(val2 = cut(val, breaks = c(-15,0,70,150,300,1000),
                                     labels = c("<15% decrease","<70% increase",
                                                "70% to 150% increase","150% to 300% increase", 
                                                 ">300% increase"),
                                     include.lowest = T,right = T))

p2 <- p + geom_polygon(data=total, 
                       aes(x=long, y=lat, group = group,fill=val2),
                       colour="black",size = .2) + 
  scale_fill_manual(values = c("#006400", "#FFE4C4", "#FF7256", "#CD3333", "#8B2323"))+
  theme_void()+labs(x="", y="")+
  guides(fill = guide_legend(title='Change in cases'))+
  theme(legend.position = 'right')
p2


## map for AAPC(平均年度百分比变化)
## AAPC
AAPC <- read.table('E:\\GBD RA\\表格\\Joinpoint\\204个国家\\DALYs-RA-AAPC.txt',header = T)
AAPC <- AAPC[,c(1,6)]



country_AAPC <- AAPC

country_AAPC$location[country_AAPC$location == "Taiwan (Province of China)"] = 'Taiwan'
country_AAPC$location[country_AAPC$location =="Micronesia (Federated States of)"]="Micronesia"
country_AAPC$location[country_AAPC$location =="Lao People's Democratic Republic"]="Laos"
country_AAPC$location[country_AAPC$location =="Czechia"]="Czech Republic"
country_AAPC$location[country_AAPC$location =="Democratic People's Republic of Korea"]="North Korea"
country_AAPC$location[country_AAPC$location =="Viet Nam"]="Vietnam"
country_AAPC$location[country_AAPC$location =="Republic of Korea"]="South Korea"
country_AAPC$location[country_AAPC$location =="Brunei Darussalam"]="Brunei" 
country_AAPC$location[country_AAPC$location =="Russian Federation"]="Russia"
country_AAPC$location[country_AAPC$location == "Antigua and Barbuda"] = 'Antigua'
country_AAPC$location[country_AAPC$location == "Republic of Moldova"] = 'Moldova'
country_AAPC$location[country_AAPC$location == 'United States of America'] = 'USA'
country_AAPC$location[country_AAPC$location == "Venezuela (Bolivarian Republic of)"] = 'Venezuela'
country_AAPC$location[country_AAPC$location == "Trinidad and Tobago"] = 'Trinidad'
country_AAPC$location[country_AAPC$location == 'United Kingdom'] = 'UK'
country_AAPC$location[country_AAPC$location == "Bolivia (Plurinational State of)"] = 'Bolivia'
country_AAPC$location[country_AAPC$location == "Saint Vincent and the Grenadines"] = 'Saint Vincent'
country_AAPC$location[country_AAPC$location == "Syrian Arab Republic"] = 'Syria'
country_AAPC$location[country_AAPC$location == "Iran (Islamic Republic of)"] = 'Iran'
country_AAPC$location[country_AAPC$location == 'Congo'] = 'Republic of Congo'
country_AAPC$location[country_AAPC$location =="Côte d'Ivoire"]="Ivory Coast"
country_AAPC$location[country_AAPC$location == "Eswatini"] = 'Swaziland'
country_AAPC$location[country_AAPC$location == "Cabo Verde"] = 'Cape Verde'
country_AAPC$location[country_AAPC$location == "Saint Kitts and Nevis"] = 'Saint Kitts'
country_AAPC$location[country_AAPC$location == "United Republic of Tanzania"] = 'Tanzania'
country_AAPC$location[country_AAPC$location == "United States Virgin Islands"] = 'Virgin Islands'
#删除两个未在worldData中出现的国家
country_AAPC <- country_AAPC[-which(country_AAPC$location %in% c("Tokelau", "Tuvalu")),]

worldData <- map_data('world')
total <- full_join(worldData,country_AAPC,by = c('region'='location'))



p <- ggplot()
p1 <- p + geom_polygon(data=total, 
                       aes(x=long, y=lat, group = group,fill=AAPC),
                       colour="black",size = .2) + 
  scale_fill_gradient2(low = "forestgreen",mid = 'white', high = "red",
                       midpoint = 0)+
  theme_void()+labs(x="", y="")+
  guides(fill = guide_colorbar(title='AAPC'))+
  theme(legend.position = 'right') 
p1



#载入sf包
library(sf)
#读取世界地图数据
map <- readRDS("map.rds")
# 读取 GBD 数据
GBD <- read.csv("GBD数据/RHD-Countries.csv")
GBD$location[GBD$location == "Türkiye"] = "Turkey"
colnames(GBD)
GBD_disease <- GBD |> filter(measure == "Deaths") |> 
  filter(year == 2021) |>
  filter(sex == "Both") |>
  filter(metric == "Rate") |>
  filter(age == "Age-standardized")
#国家名称对应问题
change_location <- read.csv("change_location.csv")
GBD$location <- ifelse(GBD$location %in% change_location$location,
                             change_location$normalized_location[match(GBD$location, 
                                                                       change_location$location)],GBD$location)
# 读取 location 数据
# GBD 的国家（或地区）名与地图上的国家（或地区）名并不能完全匹配
# location 数据是用于连接 GBD 和地图数据的中间数据
# 其中 location 与 GBD 的 location 完全一致;
#location2 与 map 数据的 FENAME 列完全一致；location3 与 map 数据的 NAME 列完全一致。
location <- read.csv("location.csv")
colnames(location)
#数据的合并连接
GBD_disease <- right_join(GBD_disease,location,by="location")
colnames(GBD_disease)
colnames(GBD_disease)[12] <- 'NAME'
df <- left_join(map,GBD_disease,by="NAME")
#绘制属性地图
fig1 <- df |>
  ggplot()+
  geom_sf(aes(group=NAME,fill=val),color="black",size=0.01)+
  theme_void()+
  scale_fill_distiller(palette="RdBu",# 色盘
                       name="ASMR")+theme(legend.position=c(0.97, .5))
###颜色标度按自己的数据选择调整
fig1




GBD <- read.csv("GBD数据/RHD-Countries-Change.csv")
GBD$location[GBD$location == "Türkiye"] = "Turkey"
colnames(GBD)
GBD_disease <- GBD |> filter(measure == "Prevalence") |> 
  filter(age == "All ages") |>
  filter(sex == "Both") |>
  filter(metric == "Number")
GBD_disease$val2 <- GBD_disease$val*100
#国家名称对应问题
change_location <- read.csv("change_location.csv")
GBD$location <- ifelse(GBD$location %in% change_location$location,
                       change_location$normalized_location[match(GBD$location, 
                                                                 change_location$location)],GBD$location)
# 读取 location 数据
# GBD 的国家（或地区）名与地图上的国家（或地区）名并不能完全匹配
# location 数据是用于连接 GBD 和地图数据的中间数据
# 其中 location 与 GBD 的 location 完全一致;
#location2 与 map 数据的 FENAME 列完全一致；location3 与 map 数据的 NAME 列完全一致。
location <- read.csv("location.csv")
colnames(location)
#数据的合并连接
GBD_disease <- right_join(GBD_disease,location,by="location")
colnames(GBD_disease)
colnames(GBD_disease)[14] <- 'NAME'
df <- left_join(map,GBD_disease,by="NAME")


test<-cbind(as.vector(df$NAME),as.vector(df$val))

#绘制属性地图
fig1 <- df |>
  ggplot()+
  geom_sf(aes(group=NAME,fill=val2),color="black",size=0.01)+
  theme_void()+
  scale_fill_distiller(palette="RdBu",# 色盘
                       name="Change in cases")
###颜色标度按自己的数据选择调整
fig1






GBD <- read.table('D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/204个国家/Prevalence-RHD-AAPC.txt',header = T)
GBD$location[GBD$location == "Türkiye"] = "Turkey"
colnames(GBD)
GBD_disease <- GBD 
#国家名称对应问题
change_location <- read.csv("change_location.csv")
GBD$location <- ifelse(GBD$location %in% change_location$location,
                       change_location$normalized_location[match(GBD$location, 
                                                                 change_location$location)],GBD$location)
# 读取 location 数据
# GBD 的国家（或地区）名与地图上的国家（或地区）名并不能完全匹配
# location 数据是用于连接 GBD 和地图数据的中间数据
# 其中 location 与 GBD 的 location 完全一致;
#location2 与 map 数据的 FENAME 列完全一致；location3 与 map 数据的 NAME 列完全一致。
location <- read.csv("location.csv")
colnames(location)
#数据的合并连接
GBD_disease <- right_join(GBD_disease,location,by="location")
colnames(GBD_disease)
colnames(GBD_disease)[13] <- 'NAME'
df <- left_join(map,GBD_disease,by="NAME")
#绘制属性地图
fig1 <- df |>
  ggplot()+
  geom_sf(aes(group=NAME,fill=AAPC),color="black",size=0.01)+
  theme_void()+
  scale_fill_gradient2(low = "forestgreen",mid = 'white', high = "red",
                       midpoint = 0)+
  guides(fill = guide_colorbar(title='AAPC'))+theme(legend.position=c(0.97, .5))
  
###颜色标度按自己的数据选择调整
fig1




















