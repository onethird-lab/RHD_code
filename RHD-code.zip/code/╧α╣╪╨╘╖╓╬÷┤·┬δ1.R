library(ggplot2)
library(patchwork)
install.packages('lemon')
install.packages('ggpubr')
library(lemon)
library(ggpubr)
#case_lm_data=fread("D:/work/研一下/GBD/GDB MS/Joinpoint/DALYs_AAPC.csv")
#RA <- read.csv('RA-Countries.csv')
RA_t=read.csv("D:/zouyuping2023/task/GBD/Disease/RHD-2/ASR、AAPC与SDI的线性和非线性关系/RHD-Countries.csv")
unique(RA_t$location) 

#Prevalence
RA_ASPR_t <- subset(RA_t,RA_t$measure=='Prevalence'&
                    RA_t$sex=='Both'&
                      RA_t$age=='Age-standardized'&
                      RA_t$metric=='Rate'&
                      RA_t$year==2021)

SDI_levels <- read.csv('D:/zouyuping2023/task/GBD/Disease/RHD-2/ASR、AAPC与SDI的线性和非线性关系/SDI国家分级1.csv') #根据不同国家的SDI，将它们分为五个水平

unique(RA_ASPR_t$location)

RA_ASPR_t <- merge(RA_ASPR_t,SDI_levels,by='location')
RA_ASPR_t <- RA_ASPR_t[,c(1,8,12,13)]#1,8,12,13  #1,9,13,14
mytheme <- theme(plot.title = element_text(face="bold.italic",size=14,color="brown"),
                 axis.title = element_text(face="bold.italic",size=13,color="brown"),
                 axis.text = element_text(face="bold",size=9,color="darkblue"),
                 panel.background = element_rect(fill="white",color="darkblue"),
                 panel.grid.major.y = element_blank(),
                 panel.grid.minor.y = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 legend.position = "top")
RA_ASPR_t$levels <- factor(RA_ASPR_t$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                   'Low-middle SDI','Low SDI'))
summary(RA_ASPR_t$sdi)#根据这里的数修改下面的XY轴范围与长度，后面几个图一样
summary(RA_ASPR_t$val)
cor.test(RA_ASPR_t$sdi,RA_ASPR_t$val,method="pearson")#下面的R和p需要根据这里修改，后面几个图一样

p1 <- ggplot(RA_ASPR_t,aes(x=sdi,y=val,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = RA_ASPR_t,aes(sdi, val),se = .8,colour='blue',span=1,method = 'lm')+
  mytheme+
  theme(legend.position = "none",legend.key = element_blank(),
#背景设为透明
  )+
  labs(x='SDI',y='ASPR (per 100,000)')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  scale_y_continuous(breaks = c(0,700,1400,2100))+
  geom_hline(yintercept = 684.2,linetype='dashed')
  #annotate("text",x=20,y=150,label='atop(R==0.60,P==2.2%*%10^-16)',parse=T)
p1





#Incidence
RA=RA_t
RA_ASIR <- subset(RA,RA$measure=='Incidence'&
                     RA$sex=='Both'&
                     RA$age=='Age-standardized'&
                     RA$metric=='Rate'&
                     RA$year==2021)
RA_ASIR <- merge(RA_ASIR,SDI_levels,by='location')
RA_ASIR <- RA_ASIR[,c(1,8,12,13)]
RA_ASIR$levels <- factor(RA_ASIR$levels,levels = c('High SDI','High-middle SDI','Middle SDI','Low-middle SDI','Low SDI'))

cor.test(RA_ASIR$sdi,RA_ASIR$val)
summary(RA_ASIR$sdi)
summary(RA_ASIR$val)

p2 <- ggplot(RA_ASIR,aes(x=sdi,y=val,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = RA_ASIR,aes(sdi, val),se = .8,colour='blue',span=1,method = 'lm')+
  mytheme+
  labs(x='SDI',y='ASIR (per 100,000)')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  scale_y_continuous(breaks = c(0,50,100,150))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = 50.7,linetype='dashed')
 # + annotate("text",x=20,y=6,label='atop(R==0.43,P==5.54%*%10^-11)',parse=T)
  
p2  


#DALYs
RA_ASDR <- subset(RA,RA$measure=='DALYs (Disability-Adjusted Life Years)'&
                     RA$sex=='Both'&
                     RA$age=='Age-standardized'&
                     RA$metric=='Rate'&
                     RA$year==2021)
RA_ASDR <- merge(RA_ASDR,SDI_levels,by='location')
RA_ASDR <- RA_ASDR[,c(1,8,12,13)]
RA_ASDR$levels <- factor(RA_ASDR$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                   'Low-middle SDI','Low SDI'))

cor.test(RA_ASDR$sdi,RA_ASDR$val)
summary(RA_ASDR$sdi)
summary(RA_ASDR$val)

p3 <- ggplot(RA_ASDR,aes(x=sdi,y=val,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = RA_ASDR,aes(sdi, val),se = .8,colour='blue',span=1,method = 'gam')+
  mytheme+
  labs(x='SDI',y='ASDR (per 100,000)')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  scale_y_continuous(breaks = c(0,200,400,600))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = 162.1,linetype='dashed')
 # annotate("text",x=20,y=65,label='atop(R==-0.05,P==0.42)',parse=T)


p3  



#DEATH
RA_ASDeR <- subset(RA,RA$measure=='Deaths'&
                    RA$sex=='Both'&
                    RA$age=='Age-standardized'&
                    RA$metric=='Rate'&
                    RA$year==2021)
RA_ASDeR <- merge(RA_ASDeR,SDI_levels,by='location')
RA_ASDeR <- RA_ASDeR[,c(1,8,12,13)]
RA_ASDeR$levels <- factor(RA_ASDeR$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                   'Low-middle SDI','Low SDI'))

cor.test(RA_ASDeR$sdi,RA_ASDeR$val)
summary(RA_ASDeR$sdi)
summary(RA_ASDeR$val)

p3_2 <- ggplot(RA_ASDeR,aes(x=sdi,y=val,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = RA_ASDeR,aes(sdi, val),se = .8,colour='blue',span=1,method = 'gam')+
  mytheme+
  labs(x='SDI',y='ASDeR (per 100,000)')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  scale_y_continuous(breaks = c(0,5,10,15))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = 4.5,linetype='dashed')
#  annotate("text",x=20,y=1.5 ,label='atop(R==-0.08,P==0.21)',parse=T)


p3_2  




##AAPC
#Prevalence
RA <- read.table('D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/204个国家/Prevalence-RHD-AAPC.txt',
                              header = T)


AAPC_Prevalence <- RA[,c(1,6)]
AAPC_Prevalence <- merge(AAPC_Prevalence,SDI_levels,by='location')
AAPC_Prevalence <- AAPC_Prevalence[,c(1,2,4,5)]
AAPC_Prevalence$levels <- factor(AAPC_Prevalence$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                                   'Low-middle SDI','Low SDI'))
summary(AAPC_Prevalence$sdi)
cor.test(AAPC_Prevalence$sdi,AAPC_Prevalence$AAPC)

p4 <- ggplot(AAPC_Prevalence,aes(x=sdi,y=AAPC,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = AAPC_Prevalence,aes(sdi, AAPC),se = .8,colour='blue',span=1,method = 'gam')+
  mytheme+
  labs(x='SDI',y='AAPC')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = 0.3834,linetype='dashed')
  #annotate("text",x=20,y=2,label='atop(R==0.06,P==0.4)',parse=T)


p4  

#Incidence
RA <- read.table('D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/204个国家/Incidence-RHD-AAPC.txt',
                 header = T)



AAPC_Incidence <- RA[,c(1,6)]
AAPC_Incidence <- merge(AAPC_Incidence,SDI_levels,by='location')
AAPC_Incidence <- AAPC_Incidence[,c(1,2,4,5)]
AAPC_Incidence$levels <- factor(AAPC_Incidence$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                                   'Low-middle SDI','Low SDI'))
cor.test(AAPC_Incidence$sdi,AAPC_Incidence$AAPC)

p5 <- ggplot(AAPC_Incidence,aes(x=sdi,y=AAPC,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = AAPC_Incidence,aes(sdi, AAPC),se = .8,colour='blue',span=1,method = 'gam')+
  mytheme+
  labs(x='SDI',y='AAPC')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = 0.1388,linetype='dashed')
#  annotate("text",x=20,y=2,label='atop(R==0.10,P==0.14)',parse=T)
p5


#DALYs
RA <- read.table('D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/204个国家/DALYs-RHD-AAPC.txt',header = T)
AAPC_DALYs <- RA[,c(1,6)]
AAPC_DALYs <- merge(AAPC_DALYs,SDI_levels,by='location')
AAPC_DALYs <- AAPC_DALYs[,c(1,2,4,5)]
AAPC_DALYs$levels <- factor(AAPC_DALYs$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                                 'Low-middle SDI','Low SDI'))
cor.test(AAPC_DALYs$sdi,AAPC_DALYs$AAPC)

p6 <- ggplot(AAPC_DALYs,aes(x=sdi,y=AAPC,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = AAPC_DALYs,aes(sdi, AAPC),se = .8,colour='blue',span=1,method = 'gam')+
  mytheme+
  labs(x='SDI',y='AAPC')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = -2.4445 ,linetype='dashed')
#  annotate("text",x=20,y=2,label='atop(R==-0.11,P==0.12)',parse=T)
p6


#DEATH
RA <- read.table('D:/zouyuping2023/task/GBD/Disease/RHD-2/Joinpoint/204个国家/DALYs-RHD-AAPC.txt',header = T)
AAPC_DEATH <- RA[,c(1,6)]
AAPC_DEATH <- merge(AAPC_DEATH,SDI_levels,by='location')
AAPC_DEATH <- AAPC_DEATH[,c(1,2,4,5)]
AAPC_DEATH$levels <- factor(AAPC_DEATH$levels,levels = c('High SDI','High-middle SDI','Middle SDI',
                                                         'Low-middle SDI','Low SDI'))

cor.test(AAPC_DEATH$sdi,AAPC_DEATH$AAPC)
p6_2 <- ggplot(AAPC_DEATH,aes(x=sdi,y=AAPC,color=levels))+
  geom_point()+
  scale_color_manual(values = c('#ef1828','#f88421','#3cb346','#942d8d','#006b7b'))+
  geom_smooth(data = AAPC_DEATH,aes(sdi, AAPC),se = .8,colour='blue',span=1,method = 'gam')+
  mytheme+
  labs(x='SDI',y='AAPC')+
  scale_x_continuous(breaks = c(20,40,60,80))+
  theme(legend.position = 'none')+
  geom_hline(yintercept = -2.6286,linetype='dashed')
 # annotate("text",x=20,y=2,label='atop(R==-0.13,P==6.35%*%10^-2)',parse=T)
p6_2





p7 <- ggarrange(p1,p2,p3,p3_2,p4,p5,p6,p6_2,ncol = 4, nrow = 2, common.legend = TRUE, legend = "top")
p7


