###孟德尔随机化
library('devtools')
library(data.table)
install_github("MRCIEU/TwoSampleMR") #安装TwoSampleMR包
library('TwoSampleMR') 
#读取VCF文件，我这里下载了IEU数据库数据
data <- vcfR::read.vcfR('E:/孟德尔随机化分析/吸烟暴露数据/ukb-b-223.vcf.gz')
data <- fread('E:/孟德尔随机化分析/吸烟暴露数据/ukb-a-16.vcf.gz')
#如注释文件所示，ES代表beta值、SE代表se、LP代表-log10（P值）、AF代表eaf、“ID”代表SNP的ID
gt <- data.frame(data@gt)
dat <- as.character(unlist(strsplit(gt$UKB.b.223, split = ":")))#strsplit切分；unlist解开
fix<-data.frame(data@fix)#为SNP位点的基本信息
#转化为data.frame
matrix<-matrix(data=dat,ncol=6,byrow=T)
frame<-data.frame(matrix) 
# 获取到的列命名
colnames(frame)<-c("ES","SE","LP","AF","SS","ID")
exp<-cbind(fix,frame)
exp$LP <- as.numeric(exp$LP)
# 假设log10P值存储在变量log10P中
a <- -exp$LP

# 将-log10P值还原为原始P值
a <- 10^a
exp2 <- exp
exp2$LP <- a
exp3 <- subset(exp2,exp2$LP < 5e-8)
write.csv(exp3,'E:/孟德尔随机化/SNP.csv')
data_pflt <- subset(data,data$p_value < 1e-5)

a <- read.xlsx('E:/孟德尔随机化分析/吸烟暴露数据/SmkInit.xlsx')

write.csv(data_pflt,'clock_4288.csv')
Clock<-system.file("MRlearning/clock_4288.csv",package = "TwoSampleMR")
Clock_exp_dat<-read_exposure_data(filename = 'E:/孟德尔随机化/SNP.csv' ,
                                sep = ",",
                                snp_col = "variant_id",
                                beta_col = "Effect",
                                se_col = "SE",
                                effect_allele_col = "A1",
                                other_allele_col = "A2",
                                eaf_col = "Freq1",
                                clump = FALSE)



#独立性设置，进行clump去除连锁
Clock_exp_dat_clumped<-clump_data(Clock_exp_dat,
                                  clump_kb = 10000,
                                  clump_r2 = 0.001,
                                  clump_p1 = 1,
                                  clump_p2 = 1
                                               )



#读取RA数据
setwd("E:/孟德尔随机化/GWAS双样本孟德尔随机化/表观年龄加速/")#设置工作路径
c <- read.delim('IEAA_EUR_summary_statistics.tsv',header = T)

#将暴露SNP从结局中提取出来，取交集
d<-merge(Clock_exp_dat_clumped,chd_out_dat,by.x = "SNP",by.y = "SNP")
write.csv(d, file="outcome.csv") 

#通过“read_outcome_data”函数，处理Outcome数据
outcome_dat<-read_outcome_data(snps = PostSmk_exp_dat_clumped$SNP,
                               filename = "outcome3.csv",
                               sep = ",",
                               snp_col = "SNP",
                               beta_col = "beta",
                               se_col = "standard_error",
                               effect_allele_col = "effect_allele",
                               other_allele_col = "other_allele",
                               pval_col = "p_value",
                               eaf_col = "effect_allele_frequency")

#协同
dat_harmonise<-harmonise_data(exposure_dat = Clock_exp_dat_clumped,
                    outcome_dat = chd_out_dat)
write.csv(dat_harmonise, file="harmonized_data2.csv") 
####3、进行MR#### 
mr(dat_harmonise)
generate_odds_ratios(mr_res = mr(dat_harmonise)) 


mr_method_list()#查看TwoSampleMR包里的mr方法
mr(dat_harmonise,method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median"))#选择所用的MR方法

#结果可视化
mr_scatter_plot(mr_results = mr(dat_harmonise,method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median")),dat_harmonise)
#异质性检测
mr_heterogeneity(dat)

#run_mr_presso(dat,NbDistribution =3000)
#异质性可视化，对称，异质性越小
mr_funnel_plot(singlesnp_results = mr_singlesnp(dat_harmonise))

#多效性检测，使用egger_intercept,评估截距是否大于0.05
mr_pleiotropy_test(dat_harmonise)

mr_leaveoneout_plot(leaveoneout_results = mr_leaveoneout(dat_harmonise))


#_________________________________________________________________________
###孟德尔随机化
#安装并加载所需的包
install.packages("remotes")
library(remotes)
remotes::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(stringr)

#1.获取暴露数据
#获取ieu open gwas project的GWAS summary statistics总表
#获取总表需要VPN服务，这里直接读取已经下载完成的总表就好了
ao <-available_outcomes(access_token = ieugwasr::check_access_token()) 
write.csv(ao,'GWAS summary statistics.csv') #将数据保存到本地
ao <- read.csv('D:/zouyuping2023/task/GBD/GWAS summary statistics.csv')
#获取与风险因素相关的研究
#smoking_id<-ao[grepl("salt", ao$trait, ignore.case = TRUE), ]
smoking_id<-ao[grepl("systolic blood pressure", ao$trait, ignore.case = TRUE), ]
smoking_id<-ao
opengwas_jwt <-"eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaS1qd3QiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJhcGkub3Blbmd3YXMuaW8iLCJhdWQiOiJhcGkub3Blbmd3YXMuaW8iLCJzdWIiOiI5MjM2NjQzOTVAcXEuY29tIiwiaWF0IjoxNzE1MzAxNTM4LCJleHAiOjE3MTY1MTExMzh9.QpYkmZAxY6KgFKW1cJ4lR6-YHdwCaOTIEWtWR1UewdF4gxQvqvXrMKbAUP-NvhF7WEdV9IXIROXgEPFZIlmN5B8eKc8g2GlT46OYCxS5QIeqAXXAeB_lloGEZTmrS01N62BPJ4EvhNYexB2gR3rRPKObkSnV7zLvzUfHSrAGTBztFuW-fs2v2xkV3RRYABPv-_gUPfJJHYNU1dnn4AZfcb4kSN6MafCZfJESuLSNJDeMLtOewsLt7fZY1uaJXdqv-evMkbS7-Lx_-ya2MHAwS0he2uU8bO-kfi28_Y0cwNK4ybG3UwpLBVBEXHV3uKjfG6BOMWSvfdZezxOtCXl65w"
#smoking_exposure_data <- extract_instruments('ieu-b-104', p1=5e-08, clump = F,opengwas_jwt = opengwas_jwt)
smoking_exposure_data <- extract_instruments('ieu-b-104', p1=5e-08, clump = F,opengwas_jwt = opengwas_jwt)

#smoking_exposure_data <- extract_instruments('ukb-e-20116_p3_CSA', p1=5e-08, clump = F)

#根据标准阈值筛选出的SNP数量大于20，可进行后续分析，阈值最小标准为1e-5（需要进行敏感性分析提供支持）
#2.去除连锁不平衡位点

#ieugwasr::api_status()
options(ieugwasr_api = 'gwas-api.mrcieu.ac.uk/')
smoking_exposure_data_clumped <- clump_data(smoking_exposure_data,
                                    clump_kb = 10000,
                                    clump_r2 = 0.001,
                                    clump_p1 = 1,
                                    clump_p2 = 1,
                                    pop = "EUR")
#如在上一步基础上SNP过滤较多，也可调整参数（r2=0.1, kb=5000）
#3.结局数据获取
RA_id <-  ao[grepl("Rheumatic", ao$trait, ignore.case = TRUE), ]
RA_outcome_data <- extract_outcome_data(snps=smoking_exposure_data_clumped$SNP,
                                   outcomes = 'finn-b-I9_VHD',proxies = T)
#smoking_exposure_data_clumped$samplesize.exposure<-46368
smoking_exposure_data_clumped$R=get_r_from_bsen(smoking_exposure_data_clumped$beta.exposure,
                                                smoking_exposure_data_clumped$se.exposure,
                                                smoking_exposure_data_clumped$samplesize.exposure)
r_2=sum(smoking_exposure_data_clumped$R*smoking_exposure_data_clumped$R)
N=smoking_exposure_data_clumped$samplesize.exposure[1]
K=nrow(smoking_exposure_data_clumped)
F_stat=r_2/(1-r_2)*((N-K-1)/K)
#4.统一格式
dat <- harmonise_data(
  exposure_dat = smoking_exposure_data_clumped, 
  outcome_dat = RA_outcome_data)

colnames(dat)###########需要修改
output_excel<-dat[,c(1,14,15,2,3,8,6,26,27,7,16,18)]
colnames(output_excel)
output_excel<-output_excel[order(as.numeric(output_excel$chr)),]
write.csv(output_excel,"D:/zouyuping2023/task/GBD/Disease/RHD/MR/result-HbA1C/HbA1C_excel.csv",row.names=F)
#5.孟德尔随机化分析
res_one <- mr(dat)
res_one
#结果解读：默认方法为五种，其中以逆方差加权法为金标准，其结果p值<0.05即可认为具有因果效应。但需要
#满足的条件为：五种默认方法的beta值霍or值方向具有一致性。

# res <- mr(dat,method_list=c("mr_egger_regression", "mr_ivw"))，这里可以自己选择方法

#二分类变量使用OR值及其置信区间
res_or <- generate_odds_ratios(res_one)

#该包提供的计算OR置信区间的函数有误，进行以下处理
res_or$or_se <- abs(log(res_or$or)/qnorm(res_or$pval/2))
res_or$or_lci95 <- res_or$or - res_or$or_se*1.96
res_or$or_uci95 <- res_or$or + res_or$or_se*1.96

write.csv(res_or,'D:/zouyuping2023/task/GBD/Disease/RHD/MR/result-HbA1C/expose-HbA1C.csv',row.names = F)

#6.检验
# （1）异质性检验（Heterogeneity test）：主要是检验各个工具变量之间的差异，
#                                        如果不同工具变量之间的差异大，
#                                        那么这些工具变量的异质性就大。
mr_heterogeneity(dat)
#结果
#id.exposure         id.outcome                                                       outcome
#1    ukb-a-16 ebi-a-GCST90014288 DNA methylation GrimAge acceleration || id:ebi-a-GCST90014288
#2    ukb-a-16 ebi-a-GCST90014288 DNA methylation GrimAge acceleration || id:ebi-a-GCST90014288
#exposure                    method        Q Q_df    Q_pval
#1 Current tobacco smoking || id:ukb-a-16                  MR Egger 6.549130   14 0.9506996
#2 Current tobacco smoking || id:ukb-a-16 Inverse variance weighted 6.549987   15 0.9689570
#Q_pval远大于0.05，所以可以认为工具变量之间不存在异质性


#（2）多效性检验 （Pleiotropy test）：主要检验多个工具变量是否存在水平多效性，
#                                     常用MR Egger法的截距项表示，如果该截距项与0差异很大，
#                                     说明存在水平多效性。
#                                     除此以外，MR-PRESSO包也是常用的检验水平多效性的R包。
mr_pleiotropy_test(dat)
#结果
#id.exposure         id.outcome                                                       outcome
#1    ukb-a-16 ebi-a-GCST90014288 DNA methylation GrimAge acceleration || id:ebi-a-GCST90014288
#exposure egger_intercept         se      pval
#1 Current tobacco smoking || id:ukb-a-16   -0.0009978942 0.03408055 0.9770542
#水平多效性常用MR Egger法的截距项表示，如果该截距项与0差异很大，说明存在水平多效性。
#在结果中已知截距与0非常接近，且p值远大于0.05，所以没有水平多效性存在




# （3）逐个剔除检验 （Leave-one-out sensitivity test）：主要是逐个剔除IV后计算剩下IV的MR结果，
#                           如果剔除某个IV后其它IV估计出来的MR结果和总结果差异很大，
#                           说明MR结果对该IV是敏感的。
single <- mr_leaveoneout(dat)


#7. 作图
#散点图
plot <- mr_scatter_plot(res_one, dat)#工具变量（SNP）与暴露和结局的关联
plot

#标准森林图（SNP与结局的关联强度）
res_single <- mr_singlesnp(dat)
p2 <- mr_forest_plot(res_single)
p2
#留一法森林图（MR结果对某一工具变量的敏感度）
single <- mr_leaveoneout(dat)
p3 <- mr_leaveoneout_plot(single)
p3
#漏斗图（异质性检验可视化）
p4 <- mr_funnel_plot(res_single)
p4

#8.图片美化---森林图
library(dplyr)
library(grid)
install.packages("forestploter")
library(forestploter)
Data <- read.csv('D:/zouyuping2023/task/GBD/Disease/RHD/MR/result-HbA1C/expose-HbA1C.csv')

#生成or(95% CI)
Data$'OR (95% CI)' <- ifelse(is.na(Data$or_uci95), "",
                             sprintf("%.2f (%.2f to %.2f)",
                                     Data$or, Data$or_lci95, Data$or_uci95))#sprintF返回字符和可变量组合

#给它把第一个变量空一格，等下绘图的时候好看点
Data$Outcome<- ifelse(!is.na(Data$sample.size), Data$Outcome, paste0("   ", Data$Outcome))
#sample size、P-Value变量等下要来绘图，我们把缺失的地方变成空格
Data$sample.size <- ifelse(is.na(Data$sample.size), "", Data$sample.size)
Data$P.value <- ifelse(is.na(Data$P.value), "", Data$P.value)

#生成一个空的绘图区间
Data$' ' <- paste(rep(" ", 8), collapse = " ")
#为表格重新命名
colnames(Data)[4] <- 'P-value'
colnames(Data)[2] <- 'Sample Size'
#绘图

plot_Smoking_forest <- forest(Data[,c(1,2,3,8,9,4)],
                              est = Data$or,       #效应值
                              lower = round(Data$or_lci95,6),     #可信区间下限
                              upper = Data$or_uci95,      #可信区间上限
                              sizes = 0.5,     #置信区间正方形的大小，可自己调整
                              ci_column = 5,   #在那一列画森林图，要选空的那一列
                              ref_line = 1,
                              xlim = NULL,
                              ticks_at = c(0,1,2),
  
                              theme = tm)
plot_Smoking_forest
##个别细节调整可在AI里操作













#森林图格式
tm <- forest_theme(base_size = 10,  #文本的大小
                   # Confidence interval point shape, line type/color/width
                   ci_pch = 15,   #可信区间点的形状
                   ci_col = "#762a83",    #CI的颜色
                   ci_fill = "blue",     #ci颜色填充
                   ci_alpha = 0.8,        #ci透明度
                   ci_lty = 1,            #CI的线型
                   ci_lwd = 1.5,          #CI的线宽
                   ci_Theight = 0.2, # Set an T end at the end of CI  ci的高度，默认是NULL
                   # Reference line width/type/color   参考线默认的参数，中间的竖的虚线
                   refline_lwd = 1,       #中间的竖的虚线
                   refline_lty = "dashed",
                   refline_col = "grey20",
                   # Vertical line width/type/color  垂直线宽/类型/颜色   可以添加一条额外的垂直线，如果没有就不显示
                   vertline_lwd = 1,              #可以添加一条额外的垂直线，如果没有就不显示
                   vertline_lty = "dashed",
                   vertline_col = "grey20",
                   # Change summary color for filling and borders   更改填充和边框的摘要颜色
                   summary_fill = "yellow",       #汇总部分大菱形的颜色
                   summary_col = "#4575b4",
                   # Footnote font size/face/color  脚注字体大小/字体/颜色
                   footnote_cex = 0.6,
                   footnote_fontface = "italic",
                   footnote_col = "red")


###为了快速找到满足因果关系的数据集，可以采取以下方式对数据集进行快速筛选
##如果最后提取出的暴露GWAS id多于结局，应以结局为主，多个暴露因素GWAS id对某一种结局id
#多个暴露因素（也可是一种暴露因素的多个GWAS id）对某一种结局的影响

smoking_id<-ao[grepl("Risk factor", ao$category, ignore.case = TRUE), ]

RA_id <-  ao[grepl("Rheumatic", ao$trait, ignore.case = TRUE), ]
RA_id <- RA_id[which(RA_id$ncase > 100), ]
exp_dat <- extract_instruments(outcomes = smoking_id$id,p1 = 5e-8)
table(exp_dat$exposure)
chd_out_dat <- extract_outcome_data(
  snps = exp_dat$SNP,
  outcomes = 'finn-b-I9_VHD',proxies = F
)
dat2 <- harmonise_data(
  exposure_dat = exp_dat, 
  outcome_dat = chd_out_dat
)
res <- mr(dat2)

# default is to subset on either the IVW method (>1 instrumental SNP) or Wald ratio method (1 instrumental SNP). 
#res <- subset_on_method(res) 
# this sorts results by decreasing effect size (largest effect at top of the plot)
# res <- sort_1_to_many(res, b = "b", sort_action = 4) 
# to keep the Y axis label clean we exclude the exposure ID labels from the exposure column 
res <- split_exposure(res) 
p_test<-res[res$pval<0.05,]
table(p_test$id.exposure)

# res$weight <- 1/res$se

min(exp(res$b - 1.96*res$se)) # identify value for 'lo' in forest_plot_1_to_many
max(exp(res$b + 1.96*res$se)) # identify value for 'up' in forest_plot_1_to_many

forest_plot_1_to_many(
  res,
  b = "b",
  se = "se",
  exponentiate = TRUE,
  ao_slc = FALSE,
  lo = 1,
  up = 30,
  TraitM = "id.exposure",
  col1_width = 2,
  by = NULL,
  trans = "log2",
  xlab = "OR for CHD per SD increase in risk factor (95% confidence interval)"
  #weight = "weight"
)



##风险因素对多种疾病的影响
exp_dat <- extract_instruments(outcomes = 'ieu-b-4877',p1 = 5e-8,clump = F) # extract instruments for smoking
exp_dat_clumped <- clump_data(
  exp_dat,
  clump_kb = 10000,
  clump_r2 = 0.001,
  clump_p1 = 1,
  clump_p2 = 1,
  pop = "EUR"
)


dis_dat <- extract_outcome_data(
  snps = exp_dat_clumped$SNP,
  outcomes = c('ebi-a-GCST000679','ieu-a-834'),
  proxies = F
)
table(dis_dat$outcome)
dat3 <- harmonise_data(
  exposure_dat = exp_dat_clumped, 
  outcome_dat = dis_dat
)


res <- mr(dat3, method_list = c("mr_egger_regression", "mr_ivw"))
res
res <- split_outcome(res) 
# to keep the Y axis label clean we exclude the exposure ID labels from the exposure column 

res <- sort_1_to_many(res, b = "b", sort_action = 4) 
# this sorts results by decreasing effect size (largest effect at top of the plot)
plot <- forest_plot_1_to_many(
  res,
  b = "b",
  se = "se",
  exponentiate = TRUE,
  trans = "log2",
  ao_slc = FALSE,
  lo = 0.5,
  up = 2.5,
  col1_width = 2,
  TraitM = "outcome",
  col_text_size = 3,
  xlab = "",
)
plot









